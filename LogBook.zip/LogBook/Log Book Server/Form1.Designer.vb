﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.TesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HapusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PanelPerintah = New System.Windows.Forms.Panel()
        Me.Perintah_Button = New System.Windows.Forms.Button()
        Me.nokomputer_Perintah = New System.Windows.Forms.TextBox()
        Me.aksi_Perintah = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel_Tombol = New System.Windows.Forms.Panel()
        Me.ButtonHapusPengguna = New System.Windows.Forms.Button()
        Me.ButtonSelesaiPenggunaan = New System.Windows.Forms.Button()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.gantiaslab = New System.Windows.Forms.Button()
        Me.lab = New System.Windows.Forms.TextBox()
        Me.aslab = New System.Windows.Forms.TextBox()
        Me.Credit = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.PanelPerintah.SuspendLayout()
        Me.Panel_Tombol.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4})
        Me.DataGridView1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.DataGridView1.Location = New System.Drawing.Point(14, 75)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.NullValue = Nothing
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.Size = New System.Drawing.Size(674, 451)
        Me.DataGridView1.TabIndex = 1
        '
        'Column1
        '
        Me.Column1.HeaderText = "Komputer"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.HeaderText = "NIM"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.HeaderText = "Nama"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        '
        'Column4
        '
        Me.Column4.HeaderText = "Tujuan"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TesToolStripMenuItem, Me.HapusToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(180, 48)
        '
        'TesToolStripMenuItem
        '
        Me.TesToolStripMenuItem.Name = "TesToolStripMenuItem"
        Me.TesToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.TesToolStripMenuItem.Text = "Selesai Penggunaan"
        '
        'HapusToolStripMenuItem
        '
        Me.HapusToolStripMenuItem.Name = "HapusToolStripMenuItem"
        Me.HapusToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.HapusToolStripMenuItem.Text = "Hapus Pengguna"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label1.Location = New System.Drawing.Point(42, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(247, 34)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Log Book Server"
        '
        'Panel1
        '
        Me.Panel1.AutoSize = True
        Me.Panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Panel1.Controls.Add(Me.PanelPerintah)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Controls.Add(Me.Panel_Tombol)
        Me.Panel1.Location = New System.Drawing.Point(48, 96)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(691, 529)
        Me.Panel1.TabIndex = 7
        '
        'PanelPerintah
        '
        Me.PanelPerintah.Controls.Add(Me.Perintah_Button)
        Me.PanelPerintah.Controls.Add(Me.nokomputer_Perintah)
        Me.PanelPerintah.Controls.Add(Me.aksi_Perintah)
        Me.PanelPerintah.Location = New System.Drawing.Point(474, 10)
        Me.PanelPerintah.Name = "PanelPerintah"
        Me.PanelPerintah.Size = New System.Drawing.Size(204, 59)
        Me.PanelPerintah.TabIndex = 16
        '
        'Perintah_Button
        '
        Me.Perintah_Button.Location = New System.Drawing.Point(116, 4)
        Me.Perintah_Button.Name = "Perintah_Button"
        Me.Perintah_Button.Size = New System.Drawing.Size(75, 47)
        Me.Perintah_Button.TabIndex = 2
        Me.Perintah_Button.Text = "JALANKAN"
        Me.Perintah_Button.UseVisualStyleBackColor = True
        '
        'nokomputer_Perintah
        '
        Me.nokomputer_Perintah.Location = New System.Drawing.Point(10, 8)
        Me.nokomputer_Perintah.Name = "nokomputer_Perintah"
        Me.nokomputer_Perintah.Size = New System.Drawing.Size(100, 20)
        Me.nokomputer_Perintah.TabIndex = 1
        Me.nokomputer_Perintah.Text = "No Komputer"
        '
        'aksi_Perintah
        '
        Me.aksi_Perintah.FormattingEnabled = True
        Me.aksi_Perintah.Items.AddRange(New Object() {"masuk", "bypass", "matikan", "restart"})
        Me.aksi_Perintah.Location = New System.Drawing.Point(10, 30)
        Me.aksi_Perintah.Name = "aksi_Perintah"
        Me.aksi_Perintah.Size = New System.Drawing.Size(100, 21)
        Me.aksi_Perintah.TabIndex = 0
        Me.aksi_Perintah.Text = "Perintah"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label2.Location = New System.Drawing.Point(20, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(121, 19)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Pengguna Lab"
        '
        'Panel_Tombol
        '
        Me.Panel_Tombol.Controls.Add(Me.ButtonHapusPengguna)
        Me.Panel_Tombol.Controls.Add(Me.ButtonSelesaiPenggunaan)
        Me.Panel_Tombol.Location = New System.Drawing.Point(146, 10)
        Me.Panel_Tombol.Name = "Panel_Tombol"
        Me.Panel_Tombol.Size = New System.Drawing.Size(200, 59)
        Me.Panel_Tombol.TabIndex = 17
        '
        'ButtonHapusPengguna
        '
        Me.ButtonHapusPengguna.ForeColor = System.Drawing.SystemColors.InfoText
        Me.ButtonHapusPengguna.Location = New System.Drawing.Point(101, 6)
        Me.ButtonHapusPengguna.Name = "ButtonHapusPengguna"
        Me.ButtonHapusPengguna.Size = New System.Drawing.Size(75, 43)
        Me.ButtonHapusPengguna.TabIndex = 4
        Me.ButtonHapusPengguna.Text = "HAPUS"
        Me.ButtonHapusPengguna.UseVisualStyleBackColor = True
        '
        'ButtonSelesaiPenggunaan
        '
        Me.ButtonSelesaiPenggunaan.ForeColor = System.Drawing.SystemColors.InfoText
        Me.ButtonSelesaiPenggunaan.Location = New System.Drawing.Point(20, 6)
        Me.ButtonSelesaiPenggunaan.Name = "ButtonSelesaiPenggunaan"
        Me.ButtonSelesaiPenggunaan.Size = New System.Drawing.Size(75, 43)
        Me.ButtonSelesaiPenggunaan.TabIndex = 3
        Me.ButtonSelesaiPenggunaan.Text = "SELESAI"
        Me.ButtonSelesaiPenggunaan.UseVisualStyleBackColor = True
        '
        'WebBrowser1
        '
        Me.WebBrowser1.AllowWebBrowserDrop = False
        Me.WebBrowser1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WebBrowser1.IsWebBrowserContextMenuEnabled = False
        Me.WebBrowser1.Location = New System.Drawing.Point(801, 157)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(320, 464)
        Me.WebBrowser1.TabIndex = 10
        Me.WebBrowser1.Url = New System.Uri("http://192.168.5.164/log_book/Chat/index/", System.UriKind.Absolute)
        Me.WebBrowser1.WebBrowserShortcutsEnabled = False
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Black", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label3.Location = New System.Drawing.Point(917, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(129, 23)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Laboratorium"
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Black", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label4.Location = New System.Drawing.Point(987, 65)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 23)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Aslab"
        '
        'gantiaslab
        '
        Me.gantiaslab.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gantiaslab.ForeColor = System.Drawing.SystemColors.InfoText
        Me.gantiaslab.Location = New System.Drawing.Point(1052, 101)
        Me.gantiaslab.Name = "gantiaslab"
        Me.gantiaslab.Size = New System.Drawing.Size(251, 38)
        Me.gantiaslab.TabIndex = 13
        Me.gantiaslab.Text = "KELUAR"
        Me.gantiaslab.UseVisualStyleBackColor = True
        '
        'lab
        '
        Me.lab.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lab.Font = New System.Drawing.Font("Arial Black", 15.75!, System.Drawing.FontStyle.Bold)
        Me.lab.ForeColor = System.Drawing.SystemColors.InfoText
        Me.lab.Location = New System.Drawing.Point(1052, 12)
        Me.lab.Multiline = True
        Me.lab.Name = "lab"
        Me.lab.ReadOnly = True
        Me.lab.Size = New System.Drawing.Size(251, 38)
        Me.lab.TabIndex = 14
        '
        'aslab
        '
        Me.aslab.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.aslab.Font = New System.Drawing.Font("Arial Black", 15.75!, System.Drawing.FontStyle.Bold)
        Me.aslab.ForeColor = System.Drawing.SystemColors.InfoText
        Me.aslab.Location = New System.Drawing.Point(1052, 57)
        Me.aslab.Multiline = True
        Me.aslab.Name = "aslab"
        Me.aslab.ReadOnly = True
        Me.aslab.Size = New System.Drawing.Size(251, 38)
        Me.aslab.TabIndex = 15
        '
        'Credit
        '
        Me.Credit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Credit.AutoSize = True
        Me.Credit.Font = New System.Drawing.Font("Lucida Sans", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Credit.Location = New System.Drawing.Point(12, 661)
        Me.Credit.Name = "Credit"
        Me.Credit.Size = New System.Drawing.Size(380, 23)
        Me.Credit.TabIndex = 16
        Me.Credit.Text = "© 2017 Created by Refsi Sangkay."
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1315, 693)
        Me.Controls.Add(Me.Credit)
        Me.Controls.Add(Me.aslab)
        Me.Controls.Add(Me.lab)
        Me.Controls.Add(Me.gantiaslab)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.WebBrowser1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Log Book Server"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.PanelPerintah.ResumeLayout(False)
        Me.PanelPerintah.PerformLayout()
        Me.Panel_Tombol.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ButtonSelesaiPenggunaan As System.Windows.Forms.Button
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents TesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HapusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ButtonHapusPengguna As System.Windows.Forms.Button
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents gantiaslab As System.Windows.Forms.Button
    Friend WithEvents lab As System.Windows.Forms.TextBox
    Friend WithEvents aslab As System.Windows.Forms.TextBox
    Friend WithEvents PanelPerintah As System.Windows.Forms.Panel
    Friend WithEvents Perintah_Button As System.Windows.Forms.Button
    Friend WithEvents nokomputer_Perintah As System.Windows.Forms.TextBox
    Friend WithEvents aksi_Perintah As System.Windows.Forms.ComboBox
    Friend WithEvents Panel_Tombol As System.Windows.Forms.Panel
    Friend WithEvents Credit As System.Windows.Forms.Label

End Class
