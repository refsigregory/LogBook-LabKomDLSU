﻿Imports MySql.Data.MySqlClient
Imports Microsoft.Win32
Imports System.Data.SqlClient
Public Class Main
    Public conn As New MySqlConnection
    Public cmd As MySqlCommand
    Public dr As MySqlDataReader
    Public connStr As String = "Server=192.168.5.121;User Id=user;Password=user;Database=log_system"
    Public tanggal As String = Format(Now, "yyyy-MM-dd")
    Public keluar As String = Format(Now, "dd/MM/yyyy HH:mm")
    Public logs As String
    Public chat As String
    Public NamaAslab As String
    Public Labs As String = Login.Lab.Text
    Public username As String = Login.UsernameTextBox.Text
    Public Sub Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Wallpaper Desktop
        Dim RKey = Registry.CurrentUser.OpenSubKey("Control Panel\Desktop", False)
        Me.BackgroundImage = Image.FromFile(RKey.GetValue("Wallpaper"))

        Panel1.BackColor = Color.FromArgb(50, 50, 50, 50)
        Label1.BackColor = Color.FromArgb(0, 50, 50, 50)
        Label2.BackColor = Color.FromArgb(0, 50, 50, 50)
        Label3.BackColor = Color.FromArgb(0, 50, 50, 50)
        Label4.BackColor = Color.FromArgb(0, 50, 50, 50)

        If conn Is Nothing Or Not conn.State = ConnectionState.Open Then 'jika tidak ada koneksi atau koneksi mysql tidak dibuka
            'Membuat ConnectionString berdasarkan data yang diisi pada textbox
            'Membuat koneksi mysql baru
            conn = New MySqlConnection(connStr)
            'membuka koneksi mysql
            conn.Open()
        End If
        'mysqlcommand untuk memilih semua kolom pada tabel user
        cmd = New MySqlCommand("SELECT nama,id FROM `users` WHERE `username`='" + username + "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        NamaAslab = dr.Item("nama")
        Dim iduser As String = dr.Item("id")
        lab.Text = Labs
        aslab.Text = NamaAslab
        WebBrowser1.Navigate("http://192.168.5.164/log_book/Chat/index/" + iduser + "#send")
        Login.TopMost = False
        Login.Close()
        Timer1.Start()
        Data()
        CekLog()
        CekChat()
        MsgBox("" + logs + " Pengguna sedang Menggunakan komputer.", vbInformation + vbOKOnly, "Informasi")
    End Sub
    Public Sub CekLog()
        If conn Is Nothing Or Not conn.State = ConnectionState.Open Then 'jika tidak ada koneksi atau koneksi mysql tidak dibuka
            'Membuat ConnectionString berdasarkan data yang diisi pada textbox
            'Membuat koneksi mysql baru
            conn = New MySqlConnection(connStr)
            'membuka koneksi mysql
            conn.Open()
        End If
        'mysqlcommand untuk memilih semua kolom pada tabel user
        cmd = New MySqlCommand("SELECT count(komputer) as jumlah FROM `log_list` WHERE `keluar`='' and `tanggal`='" + tanggal + "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()

        logs = dr.Item("jumlah")
    End Sub
    Public Sub CekChat()
        conn.Close()
        If conn Is Nothing Or Not conn.State = ConnectionState.Open Then 'jika tidak ada koneksi atau koneksi mysql tidak dibuka
            'Membuat ConnectionString berdasarkan data yang diisi pada textbox
            'Membuat koneksi mysql baru
            conn = New MySqlConnection(connStr)
            'membuka koneksi mysql
            conn.Open()
        End If
        'mysqlcommand untuk memilih semua kolom pada tabel user
        cmd = New MySqlCommand("SELECT count(text) as jumlah FROM `chat`", conn)
        dr = cmd.ExecuteReader
        dr.Read()

        chat = dr.Item("jumlah")
        conn.Close()
    End Sub
    Sub Data()
        conn.Close()
        If conn Is Nothing Or Not conn.State = ConnectionState.Open Then 'jika tidak ada koneksi atau koneksi mysql tidak dibuka
            'Membuat ConnectionString berdasarkan data yang diisi pada textbox
            'Membuat koneksi mysql baru
            conn = New MySqlConnection(connStr)
            'membuka koneksi mysql
            conn.Open()
        End If
        'mysqlcommand untuk memilih semua kolom pada tabel user
        cmd = New MySqlCommand("SELECT komputer,lab,nim,nama,tujuan FROM `log_list` WHERE `keluar`='' and `tanggal`='" + tanggal + "'  GROUP BY `komputer` ORDER BY `komputer` ASC", conn)
        dr = cmd.ExecuteReader
        'Membersihkan Semua Baris di DataGridView
        DataGridView1.Rows.Clear()
        Do While dr.Read
            'Menambahkan baris baru pada DataGridView
            DataGridView1.Rows.Add(dr.Item("komputer"), dr.Item("nim"), dr.Item("nama"), dr.Item("tujuan"))
        Loop
        conn.Close()
    End Sub

    Sub Selesai(ByVal kueri As String)
        conn.Close()
        If conn Is Nothing Or Not conn.State = ConnectionState.Open Then 'jika tidak ada koneksi atau koneksi mysql tidak dibuka
            'Membuat ConnectionString berdasarkan data yang diisi pada textbox
            'Membuat koneksi mysql baru
            conn = New MySqlConnection(connStr)
            'membuka koneksi mysql
            conn.Open()
        End If
        Try
            cmd = New MySqlCommand(kueri, conn)

            cmd.ExecuteNonQuery()

            DataGridView1.Refresh()
            conn.Close()
            Data()

        Catch ex As Exception

            MsgBox("Perintah Gagal dijalankan.", vbExclamation + vbOKOnly, "Informasi")

        End Try
    End Sub

    Sub HapusData(ByVal kueri As String)
        conn.Close()
        If conn Is Nothing Or Not conn.State = ConnectionState.Open Then 'jika tidak ada koneksi atau koneksi mysql tidak dibuka
            'Membuat ConnectionString berdasarkan data yang diisi pada textbox
            'Membuat koneksi mysql baru
            conn = New MySqlConnection(connStr)
            'membuka koneksi mysql
            conn.Open()
        End If
        Try
            cmd = New MySqlCommand(kueri, conn)

            cmd.ExecuteNonQuery()

            MsgBox("Data Log Berhasil dihapus.", vbInformation + vbOKOnly, "Informasi")
            DataGridView1.Refresh()
            conn.Close()
            Data()

        Catch ex As Exception

            MsgBox("Data Log Gagal dihapus.", vbExclamation + vbOKOnly, "Informasi")

        End Try
    End Sub

    Public Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        DataGridView1.Refresh()
        conn.Close()
        If conn Is Nothing Or Not conn.State = ConnectionState.Open Then 'jika tidak ada koneksi atau koneksi mysql tidak dibuka
            'Membuat ConnectionString berdasarkan data yang diisi pada textbox
            'Membuat koneksi mysql baru
            conn = New MySqlConnection(connStr)
            'membuka koneksi mysql
            conn.Open()
        End If
        'mysqlcommand untuk memilih semua kolom pada tabel user
        cmd = New MySqlCommand("SELECT count(komputer) as jumlah FROM `log_list` WHERE `keluar`='' and `tanggal`='" + tanggal + "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()

        If dr.Item("jumlah") > logs Or dr.Item("jumlah") < logs Then
            logs = dr.Item("jumlah")
            Data()

        End If
        conn.Close()

        conn.Open()
        'mysqlcommand untuk memilih semua kolom pada tabel chat
        cmd = New MySqlCommand("SELECT count(text) as jumlah FROM `chat`", conn)
        dr = cmd.ExecuteReader
        dr.Read()

        If dr.Item("jumlah") > chat Or dr.Item("jumlah") < chat Then
            chat = dr.Item("jumlah")
            WebBrowser1.Refresh()
        End If
        conn.Close()
        'Membersihkan Semua Baris di DataGridView
        'DataGridView1.Rows.Clear()
        'Do While dr.Read
        'Menambahkan baris baru pada DataGridView
        '   DataGridView1.Rows.Add(dr.Item("komputer"), dr.Item("nim"), dr.Item("nama"), dr.Item("tujuan"))
        'Loop
    End Sub


    Private Sub HapusToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HapusToolStripMenuItem.Click
        If DataGridView1.RowCount > 0 Then
            Dim baris As Integer
            baris = DataGridView1.CurrentRow.Index
            'With DataGridView1
            'baris = .CurrentRow.Index
            'txtkdbarang.Text = .Item(0, baris).Value
            'txtnmbarang.Text = .Item(1, baris).Value
            'txtshape.Text = .Item(2, baris).Value
            'txtitem.Text = .Item(3, baris).Value
            ''TextBox1.Text = .Item(5, baris).Value
            'txtkdbarang.Enabled = True
            'txtkdbarang.Focus()
            'End With
            Dim SelectKomputer As String = DataGridView1.Item(0, baris).Value
            HapusData("delete from `log_list` where `komputer`=" & SelectKomputer & " and `tanggal`='" + tanggal + "'")
        End If
    End Sub

    Private Sub TesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TesToolStripMenuItem.Click
        If DataGridView1.RowCount > 0 Then
            Dim baris As Integer
            baris = DataGridView1.CurrentRow.Index
            'With DataGridView1
            'baris = .CurrentRow.Index
            'txtkdbarang.Text = .Item(0, baris).Value
            'txtnmbarang.Text = .Item(1, baris).Value
            'txtshape.Text = .Item(2, baris).Value
            'txtitem.Text = .Item(3, baris).Value
            ''TextBox1.Text = .Item(5, baris).Value
            'txtkdbarang.Enabled = True
            'txtkdbarang.Focus()
            'End With
            Dim SelectKomputer As String = DataGridView1.Item(0, baris).Value
            Selesai("update `log_list` set keluar='" & keluar & "' where `komputer`=" & SelectKomputer & " and `tanggal`='" + tanggal + "'")
        End If
    End Sub

    Private Sub ButtonSelesaiPenggunaan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSelesaiPenggunaan.Click
        If DataGridView1.RowCount > 0 Then
            Dim baris As Integer
            baris = DataGridView1.CurrentRow.Index
            Dim SelectKomputer As String = DataGridView1.Item(0, baris).Value
            Selesai("update `log_list` set keluar='" & keluar & "' where komputer=" & SelectKomputer & " and `tanggal`='" + tanggal + "'")
        End If
    End Sub

    Private Sub ButtonHapusPengguna_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonHapusPengguna.Click
        If DataGridView1.RowCount > 0 Then
            Dim baris As Integer
            baris = DataGridView1.CurrentRow.Index
            Dim SelectKomputer As String = DataGridView1.Item(0, baris).Value
            HapusData("delete from `log_list` where `komputer`=" & SelectKomputer & " and `tanggal`='" + tanggal + "'")
        End If
    End Sub

    Private Sub aslab_Click(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub aslab_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub gantiaslab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gantiaslab.Click
        Login.Show()
        Login.Hide()
        Login.Lab.Text = Labs
        Login.Show()
        conn.Close()
        Me.Close()
    End Sub

    Private Sub Perintah_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Perintah_Button.Click
        Dim lab_Perintah As String = Labs
        conn.Open()
        If aksi_Perintah.Text = "masuk" Then
            FormPerintahTamu.Show()
        Else
            Try
                cmd = New MySqlCommand("insert into `perintah` (`komputer`,`lab`,`aksi`,`tanggal`) values ('" & nokomputer_Perintah.Text & "','" & lab_Perintah & "', '" & aksi_Perintah.Text & "', '" + tanggal + "')", conn)

                cmd.ExecuteNonQuery()
                MsgBox("Perintah berhasil dijalankan.", vbInformation + vbOKOnly, "Informasi")
                conn.Close()

            Catch ex As Exception

                MsgBox("Perintah gagal dijalankan.", vbExclamation + vbOKOnly, "Informasi")

            End Try
            nokomputer_Perintah.Text = "No Komputer"
            aksi_Perintah.Text = "Perintah"
        End If
    End Sub

    Private Sub nokomputer_Perintah_TextClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nokomputer_Perintah.Click
        nokomputer_Perintah.Text = ""
    End Sub

    Private Sub nokomputer_Perintah_Validated1(ByVal sender As Object, ByVal e As System.EventArgs) Handles nokomputer_Perintah.Validated
        If nokomputer_Perintah.Text = "" Then
            nokomputer_Perintah.Text = "No Komputer"
        End If
    End Sub
End Class
