﻿Imports MySql.Data.MySqlClient
Imports Microsoft.Win32
Imports System.Data.SqlClient
Public Class Login
    Public conn As New MySqlConnection
    Public cmd As MySqlCommand
    Public dr As MySqlDataReader
    Public connStr As String = "Server=192.168.5.121;User Id=user;Password=user;Database=log_system"
    Public tanggal As String = Format(Now, "yyyy-MM-dd")
    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        conn.Close()
        If conn Is Nothing Or Not conn.State = ConnectionState.Open Then 'jika tidak ada koneksi atau koneksi mysql tidak dibuka
            'Membuat ConnectionString berdasarkan data yang diisi pada textbox
            'Membuat koneksi mysql baru
            conn = New MySqlConnection(connStr)
            'membuka koneksi mysql
            conn.Open()
        End If
        'mysqlcommand untuk memilih semua kolom pada tabel user
        cmd = New MySqlCommand("SELECT nama FROM `users` WHERE `username`='" + UsernameTextBox.Text + "' and `password`='" + PasswordTextBox.Text + "' and `lab`='" + Lab.Text + "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            Main.Show()
            Me.Hide()
        Else
            MsgBox("Login Gagal! Username atau Password salah.", vbInformation + vbOKOnly)
        End If
        conn.Close()
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Application.Exit()
    End Sub

    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Lab.Focus()
    End Sub
End Class
