﻿Imports MySql.Data.MySqlClient
Imports Microsoft.Win32
Imports System.Data.SqlClient
Public Class FormPerintahTamu

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Main.conn.Open()
        Try
            Main.cmd = New MySqlCommand("insert into `perintah` (`komputer`,`lab`,`aksi`,`tanggal`,`tujuan_tamu`,`nama_tamu`) values ('" & Main.nokomputer_Perintah.Text & "','" & Main.Labs & "', '" & Main.aksi_Perintah.Text & "', '" + Main.tanggal + "','" + nama_tamu.Text + "','" + tujuan_tamu.Text + "')", Main.conn) 'diputar nama_tamu dan tujuan_tamu

            Main.cmd.ExecuteNonQuery()
            MsgBox("Perintah berhasil dijalankan.", vbInformation + vbOKOnly, "Informasi")
            Main.conn.Close()

            Main.nokomputer_Perintah.Text = "No Komputer"
            Main.aksi_Perintah.Text = "Perintah"
            Me.Close()

        Catch ex As Exception

            MsgBox("Perintah gagal dijalankan.", vbExclamation + vbOKOnly, "Informasi")


            Main.nokomputer_Perintah.Text = "No Komputer"
            Main.aksi_Perintah.Text = "Perintah"
            Me.Close()
        End Try

        Main.nokomputer_Perintah.Text = "No Komputer"
        Main.aksi_Perintah.Text = "Perintah"
    End Sub

    Private Sub FormPerintahTamu_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Main.TopMost = True
        Main.nokomputer_Perintah.Text = "No Komputer"
        Main.aksi_Perintah.Text = "Perintah"
    End Sub

    Private Sub FormPerintahTamu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Main.TopMost = False
        Me.TopLevel = True
    End Sub

    Private Sub nama_tamu_TetClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nama_tamu.Click
        nama_tamu.Text = ""
    End Sub

    Private Sub tujuan_tamu_TextClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tujuan_tamu.Click
        tujuan_tamu.Text = ""
    End Sub

    Private Sub nama_tamu_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles nama_tamu.Validated
        If nama_tamu.Text = "" Then
            nama_tamu.Text = "Guest"
        End If
    End Sub

    Private Sub tujuan_tamu_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles tujuan_tamu.Validated
        If tujuan_tamu.Text = "" Then
            tujuan_tamu.Text = "Pinjam"
        End If
    End Sub
End Class