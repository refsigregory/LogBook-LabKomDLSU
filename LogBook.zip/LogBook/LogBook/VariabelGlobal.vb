﻿Module VariabelGlobal
    Public conf_server As String = My.Settings.conf_server
    Public conf_ip As String = My.Settings.conf_ip
    Public conf_labserver As String = My.Settings.conf_labserver
    Public conf_lab As String = My.Settings.conf_lab
    Public conf_no As String = My.Settings.conf_no
    Public credits As String = My.Settings.credit
    Public conf_userdb As String = My.Settings.conf_userdb
    Public conf_passdb As String = My.Settings.conf_passdb
    Public conf_dbname As String = My.Settings.conf_dbname
End Module
