﻿Option Explicit On

Module ModMain
    Private Declare Ansi Function GetPrivateProfileString Lib "kernel32.dll" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Integer, ByVal lpFileName As String) As Integer
    Private Declare Ansi Function WritePrivateProfileString Lib "kernel32.dll" Alias "WritePrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpString As String, ByVal lpFileName As String) As Integer

    'Function to read from INI File
    Public Function GetIniSetting(ByVal strINIFile As String, ByVal strSection As String, ByVal strKey As String) As String
        Dim strValue As String = ""
        Try
            strValue = Space(1024)
            GetPrivateProfileString(strSection, strKey, "NOT_FOUND", strValue, 1024, strINIFile)
            Do While InStrRev(strValue, " ") = Len(strValue)
                strValue = Mid(strValue, 1, Len(strValue) - 1)
            Loop
            ' to remove a special chr in the last place
            strValue = Mid(strValue, 1, Len(strValue) - 1)
            GetIniSetting = strValue

        Catch ex As Exception
            If Err.Number <> 0 Then Err.Raise(Err.Number, , "Error form Functions.SetIniSettings " & Err.Description)
        End Try
        Return strValue
    End Function

    'Prosedure to write INI file
    Public Sub SetIniSettings(ByVal strINIFile As String, ByVal strSection As String, ByVal strKey As String, ByVal strValue As String)
        Try '
            WritePrivateProfileString(strSection, strKey, strValue, strINIFile)
        Catch ex As Exception
            If Err.Number <> 0 Then Err.Raise(Err.Number, , "Error form Functions.SetIniSettings " & Err.Description)
        End Try
    End Sub

End Module