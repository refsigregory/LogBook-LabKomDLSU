﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Log Book")> 
<Assembly: AssemblyDescription("Aplikasi Pengganti Buku Log Book Laboratorium")> 
<Assembly: AssemblyCompany("Refsi Sangkay")> 
<Assembly: AssemblyProduct("Log Book by Refsi Sangkay")> 
<Assembly: AssemblyCopyright("Copyright © Refsi Sangkay 2016")> 
<Assembly: AssemblyTrademark("Log Book Refsi Sangkay")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("df280eaf-2f4d-4455-926e-d2e2c6aa2630")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.7.5.0")> 
<Assembly: AssemblyFileVersion("1.7.5.0")> 
