﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Kuisioner
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Akademik = New System.Windows.Forms.GroupBox()
        Me.ss2 = New System.Windows.Forms.CheckBox()
        Me.s2 = New System.Windows.Forms.CheckBox()
        Me.n2 = New System.Windows.Forms.CheckBox()
        Me.ts2 = New System.Windows.Forms.CheckBox()
        Me.sts2 = New System.Windows.Forms.CheckBox()
        Me.ss1 = New System.Windows.Forms.CheckBox()
        Me.s1 = New System.Windows.Forms.CheckBox()
        Me.n1 = New System.Windows.Forms.CheckBox()
        Me.ts1 = New System.Windows.Forms.CheckBox()
        Me.sts1 = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Fasilitas = New System.Windows.Forms.GroupBox()
        Me.ss6 = New System.Windows.Forms.CheckBox()
        Me.s6 = New System.Windows.Forms.CheckBox()
        Me.n6 = New System.Windows.Forms.CheckBox()
        Me.ts6 = New System.Windows.Forms.CheckBox()
        Me.sts6 = New System.Windows.Forms.CheckBox()
        Me.ss5 = New System.Windows.Forms.CheckBox()
        Me.s5 = New System.Windows.Forms.CheckBox()
        Me.n5 = New System.Windows.Forms.CheckBox()
        Me.ts5 = New System.Windows.Forms.CheckBox()
        Me.sts5 = New System.Windows.Forms.CheckBox()
        Me.ss4 = New System.Windows.Forms.CheckBox()
        Me.s4 = New System.Windows.Forms.CheckBox()
        Me.n4 = New System.Windows.Forms.CheckBox()
        Me.ts4 = New System.Windows.Forms.CheckBox()
        Me.sts4 = New System.Windows.Forms.CheckBox()
        Me.ss3 = New System.Windows.Forms.CheckBox()
        Me.s3 = New System.Windows.Forms.CheckBox()
        Me.n3 = New System.Windows.Forms.CheckBox()
        Me.ts3 = New System.Windows.Forms.CheckBox()
        Me.sts3 = New System.Windows.Forms.CheckBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Layanan = New System.Windows.Forms.GroupBox()
        Me.ss12 = New System.Windows.Forms.CheckBox()
        Me.s12 = New System.Windows.Forms.CheckBox()
        Me.n12 = New System.Windows.Forms.CheckBox()
        Me.ts12 = New System.Windows.Forms.CheckBox()
        Me.sts12 = New System.Windows.Forms.CheckBox()
        Me.ss11 = New System.Windows.Forms.CheckBox()
        Me.s11 = New System.Windows.Forms.CheckBox()
        Me.n11 = New System.Windows.Forms.CheckBox()
        Me.ts11 = New System.Windows.Forms.CheckBox()
        Me.sts11 = New System.Windows.Forms.CheckBox()
        Me.ss10 = New System.Windows.Forms.CheckBox()
        Me.s10 = New System.Windows.Forms.CheckBox()
        Me.n10 = New System.Windows.Forms.CheckBox()
        Me.ts10 = New System.Windows.Forms.CheckBox()
        Me.sts10 = New System.Windows.Forms.CheckBox()
        Me.ss9 = New System.Windows.Forms.CheckBox()
        Me.s9 = New System.Windows.Forms.CheckBox()
        Me.n9 = New System.Windows.Forms.CheckBox()
        Me.ts9 = New System.Windows.Forms.CheckBox()
        Me.sts9 = New System.Windows.Forms.CheckBox()
        Me.ss8 = New System.Windows.Forms.CheckBox()
        Me.s8 = New System.Windows.Forms.CheckBox()
        Me.n8 = New System.Windows.Forms.CheckBox()
        Me.ts8 = New System.Windows.Forms.CheckBox()
        Me.sts8 = New System.Windows.Forms.CheckBox()
        Me.ss7 = New System.Windows.Forms.CheckBox()
        Me.s7 = New System.Windows.Forms.CheckBox()
        Me.n7 = New System.Windows.Forms.CheckBox()
        Me.ts7 = New System.Windows.Forms.CheckBox()
        Me.sts7 = New System.Windows.Forms.CheckBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.semester = New System.Windows.Forms.TextBox()
        Me.Akademik.SuspendLayout()
        Me.Fasilitas.SuspendLayout()
        Me.Layanan.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(582, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(134, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "KUISIONER"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Akademik
        '
        Me.Akademik.AutoSize = True
        Me.Akademik.Controls.Add(Me.ss2)
        Me.Akademik.Controls.Add(Me.s2)
        Me.Akademik.Controls.Add(Me.n2)
        Me.Akademik.Controls.Add(Me.ts2)
        Me.Akademik.Controls.Add(Me.sts2)
        Me.Akademik.Controls.Add(Me.ss1)
        Me.Akademik.Controls.Add(Me.s1)
        Me.Akademik.Controls.Add(Me.n1)
        Me.Akademik.Controls.Add(Me.ts1)
        Me.Akademik.Controls.Add(Me.sts1)
        Me.Akademik.Controls.Add(Me.Label3)
        Me.Akademik.Controls.Add(Me.Label2)
        Me.Akademik.Location = New System.Drawing.Point(37, 85)
        Me.Akademik.Name = "Akademik"
        Me.Akademik.Size = New System.Drawing.Size(1261, 77)
        Me.Akademik.TabIndex = 1
        Me.Akademik.TabStop = False
        Me.Akademik.Text = "Akademik"
        '
        'ss2
        '
        Me.ss2.AutoSize = True
        Me.ss2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss2.Location = New System.Drawing.Point(1165, 44)
        Me.ss2.Name = "ss2"
        Me.ss2.Size = New System.Drawing.Size(15, 14)
        Me.ss2.TabIndex = 11
        Me.ss2.UseVisualStyleBackColor = True
        '
        's2
        '
        Me.s2.AutoSize = True
        Me.s2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s2.Location = New System.Drawing.Point(1056, 44)
        Me.s2.Name = "s2"
        Me.s2.Size = New System.Drawing.Size(15, 14)
        Me.s2.TabIndex = 10
        Me.s2.UseVisualStyleBackColor = True
        '
        'n2
        '
        Me.n2.AutoSize = True
        Me.n2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n2.Location = New System.Drawing.Point(970, 42)
        Me.n2.Name = "n2"
        Me.n2.Size = New System.Drawing.Size(15, 14)
        Me.n2.TabIndex = 9
        Me.n2.UseVisualStyleBackColor = True
        '
        'ts2
        '
        Me.ts2.AutoSize = True
        Me.ts2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts2.Location = New System.Drawing.Point(850, 44)
        Me.ts2.Name = "ts2"
        Me.ts2.Size = New System.Drawing.Size(15, 14)
        Me.ts2.TabIndex = 8
        Me.ts2.UseVisualStyleBackColor = True
        '
        'sts2
        '
        Me.sts2.AutoSize = True
        Me.sts2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts2.Location = New System.Drawing.Point(718, 44)
        Me.sts2.Name = "sts2"
        Me.sts2.Size = New System.Drawing.Size(15, 14)
        Me.sts2.TabIndex = 7
        Me.sts2.UseVisualStyleBackColor = True
        '
        'ss1
        '
        Me.ss1.AutoSize = True
        Me.ss1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss1.Location = New System.Drawing.Point(1165, 20)
        Me.ss1.Name = "ss1"
        Me.ss1.Size = New System.Drawing.Size(15, 14)
        Me.ss1.TabIndex = 6
        Me.ss1.UseVisualStyleBackColor = True
        '
        's1
        '
        Me.s1.AutoSize = True
        Me.s1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s1.Location = New System.Drawing.Point(1056, 20)
        Me.s1.Name = "s1"
        Me.s1.Size = New System.Drawing.Size(15, 14)
        Me.s1.TabIndex = 5
        Me.s1.UseVisualStyleBackColor = True
        '
        'n1
        '
        Me.n1.AutoSize = True
        Me.n1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n1.Location = New System.Drawing.Point(970, 18)
        Me.n1.Name = "n1"
        Me.n1.Size = New System.Drawing.Size(15, 14)
        Me.n1.TabIndex = 4
        Me.n1.Tag = "1"
        Me.n1.UseVisualStyleBackColor = True
        '
        'ts1
        '
        Me.ts1.AutoSize = True
        Me.ts1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts1.Location = New System.Drawing.Point(850, 20)
        Me.ts1.Name = "ts1"
        Me.ts1.Size = New System.Drawing.Size(15, 14)
        Me.ts1.TabIndex = 3
        Me.ts1.UseVisualStyleBackColor = True
        '
        'sts1
        '
        Me.sts1.AutoSize = True
        Me.sts1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts1.Location = New System.Drawing.Point(718, 20)
        Me.sts1.Name = "sts1"
        Me.sts1.Size = New System.Drawing.Size(15, 14)
        Me.sts1.TabIndex = 2
        Me.sts1.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 44)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(301, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "2. Lab dapat digunakan untuk mendukung kegiatan penelitian" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(283, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "1. Dosen mengajar sesuai dengan jadwal yang di tentukan"
        '
        'Fasilitas
        '
        Me.Fasilitas.AutoSize = True
        Me.Fasilitas.Controls.Add(Me.ss6)
        Me.Fasilitas.Controls.Add(Me.s6)
        Me.Fasilitas.Controls.Add(Me.n6)
        Me.Fasilitas.Controls.Add(Me.ts6)
        Me.Fasilitas.Controls.Add(Me.sts6)
        Me.Fasilitas.Controls.Add(Me.ss5)
        Me.Fasilitas.Controls.Add(Me.s5)
        Me.Fasilitas.Controls.Add(Me.n5)
        Me.Fasilitas.Controls.Add(Me.ts5)
        Me.Fasilitas.Controls.Add(Me.sts5)
        Me.Fasilitas.Controls.Add(Me.ss4)
        Me.Fasilitas.Controls.Add(Me.s4)
        Me.Fasilitas.Controls.Add(Me.n4)
        Me.Fasilitas.Controls.Add(Me.ts4)
        Me.Fasilitas.Controls.Add(Me.sts4)
        Me.Fasilitas.Controls.Add(Me.ss3)
        Me.Fasilitas.Controls.Add(Me.s3)
        Me.Fasilitas.Controls.Add(Me.n3)
        Me.Fasilitas.Controls.Add(Me.ts3)
        Me.Fasilitas.Controls.Add(Me.sts3)
        Me.Fasilitas.Controls.Add(Me.Label7)
        Me.Fasilitas.Controls.Add(Me.Label6)
        Me.Fasilitas.Controls.Add(Me.Label5)
        Me.Fasilitas.Controls.Add(Me.Label4)
        Me.Fasilitas.Location = New System.Drawing.Point(37, 185)
        Me.Fasilitas.Name = "Fasilitas"
        Me.Fasilitas.Size = New System.Drawing.Size(1261, 128)
        Me.Fasilitas.TabIndex = 2
        Me.Fasilitas.TabStop = False
        Me.Fasilitas.Text = "Fasilitas"
        '
        'ss6
        '
        Me.ss6.AutoSize = True
        Me.ss6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss6.Location = New System.Drawing.Point(1165, 95)
        Me.ss6.Name = "ss6"
        Me.ss6.Size = New System.Drawing.Size(15, 14)
        Me.ss6.TabIndex = 31
        Me.ss6.UseVisualStyleBackColor = True
        '
        's6
        '
        Me.s6.AutoSize = True
        Me.s6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s6.Location = New System.Drawing.Point(1056, 95)
        Me.s6.Name = "s6"
        Me.s6.Size = New System.Drawing.Size(15, 14)
        Me.s6.TabIndex = 30
        Me.s6.UseVisualStyleBackColor = True
        '
        'n6
        '
        Me.n6.AutoSize = True
        Me.n6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n6.Location = New System.Drawing.Point(970, 93)
        Me.n6.Name = "n6"
        Me.n6.Size = New System.Drawing.Size(15, 14)
        Me.n6.TabIndex = 29
        Me.n6.UseVisualStyleBackColor = True
        '
        'ts6
        '
        Me.ts6.AutoSize = True
        Me.ts6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts6.Location = New System.Drawing.Point(850, 95)
        Me.ts6.Name = "ts6"
        Me.ts6.Size = New System.Drawing.Size(15, 14)
        Me.ts6.TabIndex = 28
        Me.ts6.UseVisualStyleBackColor = True
        '
        'sts6
        '
        Me.sts6.AutoSize = True
        Me.sts6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts6.Location = New System.Drawing.Point(718, 95)
        Me.sts6.Name = "sts6"
        Me.sts6.Size = New System.Drawing.Size(15, 14)
        Me.sts6.TabIndex = 27
        Me.sts6.UseVisualStyleBackColor = True
        '
        'ss5
        '
        Me.ss5.AutoSize = True
        Me.ss5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss5.Location = New System.Drawing.Point(1165, 70)
        Me.ss5.Name = "ss5"
        Me.ss5.Size = New System.Drawing.Size(15, 14)
        Me.ss5.TabIndex = 26
        Me.ss5.UseVisualStyleBackColor = True
        '
        's5
        '
        Me.s5.AutoSize = True
        Me.s5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s5.Location = New System.Drawing.Point(1056, 70)
        Me.s5.Name = "s5"
        Me.s5.Size = New System.Drawing.Size(15, 14)
        Me.s5.TabIndex = 25
        Me.s5.UseVisualStyleBackColor = True
        '
        'n5
        '
        Me.n5.AutoSize = True
        Me.n5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n5.Location = New System.Drawing.Point(970, 68)
        Me.n5.Name = "n5"
        Me.n5.Size = New System.Drawing.Size(15, 14)
        Me.n5.TabIndex = 24
        Me.n5.UseVisualStyleBackColor = True
        '
        'ts5
        '
        Me.ts5.AutoSize = True
        Me.ts5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts5.Location = New System.Drawing.Point(850, 70)
        Me.ts5.Name = "ts5"
        Me.ts5.Size = New System.Drawing.Size(15, 14)
        Me.ts5.TabIndex = 23
        Me.ts5.UseVisualStyleBackColor = True
        '
        'sts5
        '
        Me.sts5.AutoSize = True
        Me.sts5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts5.Location = New System.Drawing.Point(718, 70)
        Me.sts5.Name = "sts5"
        Me.sts5.Size = New System.Drawing.Size(15, 14)
        Me.sts5.TabIndex = 22
        Me.sts5.UseVisualStyleBackColor = True
        '
        'ss4
        '
        Me.ss4.AutoSize = True
        Me.ss4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss4.Location = New System.Drawing.Point(1165, 46)
        Me.ss4.Name = "ss4"
        Me.ss4.Size = New System.Drawing.Size(15, 14)
        Me.ss4.TabIndex = 21
        Me.ss4.UseVisualStyleBackColor = True
        '
        's4
        '
        Me.s4.AutoSize = True
        Me.s4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s4.Location = New System.Drawing.Point(1056, 46)
        Me.s4.Name = "s4"
        Me.s4.Size = New System.Drawing.Size(15, 14)
        Me.s4.TabIndex = 20
        Me.s4.UseVisualStyleBackColor = True
        '
        'n4
        '
        Me.n4.AutoSize = True
        Me.n4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n4.Location = New System.Drawing.Point(970, 44)
        Me.n4.Name = "n4"
        Me.n4.Size = New System.Drawing.Size(15, 14)
        Me.n4.TabIndex = 19
        Me.n4.UseVisualStyleBackColor = True
        '
        'ts4
        '
        Me.ts4.AutoSize = True
        Me.ts4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts4.Location = New System.Drawing.Point(850, 46)
        Me.ts4.Name = "ts4"
        Me.ts4.Size = New System.Drawing.Size(15, 14)
        Me.ts4.TabIndex = 18
        Me.ts4.UseVisualStyleBackColor = True
        '
        'sts4
        '
        Me.sts4.AutoSize = True
        Me.sts4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts4.Location = New System.Drawing.Point(718, 46)
        Me.sts4.Name = "sts4"
        Me.sts4.Size = New System.Drawing.Size(15, 14)
        Me.sts4.TabIndex = 17
        Me.sts4.UseVisualStyleBackColor = True
        '
        'ss3
        '
        Me.ss3.AutoSize = True
        Me.ss3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss3.Location = New System.Drawing.Point(1165, 21)
        Me.ss3.Name = "ss3"
        Me.ss3.Size = New System.Drawing.Size(15, 14)
        Me.ss3.TabIndex = 16
        Me.ss3.UseVisualStyleBackColor = True
        '
        's3
        '
        Me.s3.AutoSize = True
        Me.s3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s3.Location = New System.Drawing.Point(1056, 21)
        Me.s3.Name = "s3"
        Me.s3.Size = New System.Drawing.Size(15, 14)
        Me.s3.TabIndex = 15
        Me.s3.UseVisualStyleBackColor = True
        '
        'n3
        '
        Me.n3.AutoSize = True
        Me.n3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n3.Location = New System.Drawing.Point(970, 19)
        Me.n3.Name = "n3"
        Me.n3.Size = New System.Drawing.Size(15, 14)
        Me.n3.TabIndex = 14
        Me.n3.UseVisualStyleBackColor = True
        '
        'ts3
        '
        Me.ts3.AutoSize = True
        Me.ts3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts3.Location = New System.Drawing.Point(850, 21)
        Me.ts3.Name = "ts3"
        Me.ts3.Size = New System.Drawing.Size(15, 14)
        Me.ts3.TabIndex = 13
        Me.ts3.UseVisualStyleBackColor = True
        '
        'sts3
        '
        Me.sts3.AutoSize = True
        Me.sts3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts3.Location = New System.Drawing.Point(718, 21)
        Me.sts3.Name = "sts3"
        Me.sts3.Size = New System.Drawing.Size(15, 14)
        Me.sts3.TabIndex = 12
        Me.sts3.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 96)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(217, 13)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "4. Penerangan dalam Laboratorium memadai" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(7, 70)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(224, 26)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "3. Ketersedian jaringan internet yang memadai" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 44)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(405, 26)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "2. Ketersedian sarana pendukung pembelajaran memadai (LCD, Spidol, Papan Tulis)" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & _
            "" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(300, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "1. Ketersedian sarana pembelejaran yang memadai (komputer)" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Layanan
        '
        Me.Layanan.AutoSize = True
        Me.Layanan.Controls.Add(Me.ss12)
        Me.Layanan.Controls.Add(Me.s12)
        Me.Layanan.Controls.Add(Me.n12)
        Me.Layanan.Controls.Add(Me.ts12)
        Me.Layanan.Controls.Add(Me.sts12)
        Me.Layanan.Controls.Add(Me.ss11)
        Me.Layanan.Controls.Add(Me.s11)
        Me.Layanan.Controls.Add(Me.n11)
        Me.Layanan.Controls.Add(Me.ts11)
        Me.Layanan.Controls.Add(Me.sts11)
        Me.Layanan.Controls.Add(Me.ss10)
        Me.Layanan.Controls.Add(Me.s10)
        Me.Layanan.Controls.Add(Me.n10)
        Me.Layanan.Controls.Add(Me.ts10)
        Me.Layanan.Controls.Add(Me.sts10)
        Me.Layanan.Controls.Add(Me.ss9)
        Me.Layanan.Controls.Add(Me.s9)
        Me.Layanan.Controls.Add(Me.n9)
        Me.Layanan.Controls.Add(Me.ts9)
        Me.Layanan.Controls.Add(Me.sts9)
        Me.Layanan.Controls.Add(Me.ss8)
        Me.Layanan.Controls.Add(Me.s8)
        Me.Layanan.Controls.Add(Me.n8)
        Me.Layanan.Controls.Add(Me.ts8)
        Me.Layanan.Controls.Add(Me.sts8)
        Me.Layanan.Controls.Add(Me.ss7)
        Me.Layanan.Controls.Add(Me.s7)
        Me.Layanan.Controls.Add(Me.n7)
        Me.Layanan.Controls.Add(Me.ts7)
        Me.Layanan.Controls.Add(Me.sts7)
        Me.Layanan.Controls.Add(Me.Label14)
        Me.Layanan.Controls.Add(Me.Label13)
        Me.Layanan.Controls.Add(Me.Label12)
        Me.Layanan.Controls.Add(Me.Label11)
        Me.Layanan.Controls.Add(Me.Label10)
        Me.Layanan.Controls.Add(Me.Label9)
        Me.Layanan.Controls.Add(Me.Label8)
        Me.Layanan.Location = New System.Drawing.Point(37, 338)
        Me.Layanan.Name = "Layanan"
        Me.Layanan.Size = New System.Drawing.Size(1261, 174)
        Me.Layanan.TabIndex = 3
        Me.Layanan.TabStop = False
        Me.Layanan.Text = "Pelayanan"
        '
        'ss12
        '
        Me.ss12.AutoSize = True
        Me.ss12.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss12.Location = New System.Drawing.Point(1165, 141)
        Me.ss12.Name = "ss12"
        Me.ss12.Size = New System.Drawing.Size(15, 14)
        Me.ss12.TabIndex = 41
        Me.ss12.UseVisualStyleBackColor = True
        '
        's12
        '
        Me.s12.AutoSize = True
        Me.s12.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s12.Location = New System.Drawing.Point(1056, 141)
        Me.s12.Name = "s12"
        Me.s12.Size = New System.Drawing.Size(15, 14)
        Me.s12.TabIndex = 40
        Me.s12.UseVisualStyleBackColor = True
        '
        'n12
        '
        Me.n12.AutoSize = True
        Me.n12.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n12.Location = New System.Drawing.Point(970, 139)
        Me.n12.Name = "n12"
        Me.n12.Size = New System.Drawing.Size(15, 14)
        Me.n12.TabIndex = 39
        Me.n12.UseVisualStyleBackColor = True
        '
        'ts12
        '
        Me.ts12.AutoSize = True
        Me.ts12.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts12.Location = New System.Drawing.Point(850, 141)
        Me.ts12.Name = "ts12"
        Me.ts12.Size = New System.Drawing.Size(15, 14)
        Me.ts12.TabIndex = 38
        Me.ts12.UseVisualStyleBackColor = True
        '
        'sts12
        '
        Me.sts12.AutoSize = True
        Me.sts12.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts12.Location = New System.Drawing.Point(718, 141)
        Me.sts12.Name = "sts12"
        Me.sts12.Size = New System.Drawing.Size(15, 14)
        Me.sts12.TabIndex = 37
        Me.sts12.UseVisualStyleBackColor = True
        '
        'ss11
        '
        Me.ss11.AutoSize = True
        Me.ss11.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss11.Location = New System.Drawing.Point(1165, 116)
        Me.ss11.Name = "ss11"
        Me.ss11.Size = New System.Drawing.Size(15, 14)
        Me.ss11.TabIndex = 36
        Me.ss11.UseVisualStyleBackColor = True
        '
        's11
        '
        Me.s11.AutoSize = True
        Me.s11.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s11.Location = New System.Drawing.Point(1056, 116)
        Me.s11.Name = "s11"
        Me.s11.Size = New System.Drawing.Size(15, 14)
        Me.s11.TabIndex = 35
        Me.s11.UseVisualStyleBackColor = True
        '
        'n11
        '
        Me.n11.AutoSize = True
        Me.n11.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n11.Location = New System.Drawing.Point(970, 114)
        Me.n11.Name = "n11"
        Me.n11.Size = New System.Drawing.Size(15, 14)
        Me.n11.TabIndex = 34
        Me.n11.UseVisualStyleBackColor = True
        '
        'ts11
        '
        Me.ts11.AutoSize = True
        Me.ts11.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts11.Location = New System.Drawing.Point(850, 116)
        Me.ts11.Name = "ts11"
        Me.ts11.Size = New System.Drawing.Size(15, 14)
        Me.ts11.TabIndex = 33
        Me.ts11.UseVisualStyleBackColor = True
        '
        'sts11
        '
        Me.sts11.AutoSize = True
        Me.sts11.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts11.Location = New System.Drawing.Point(718, 116)
        Me.sts11.Name = "sts11"
        Me.sts11.Size = New System.Drawing.Size(15, 14)
        Me.sts11.TabIndex = 32
        Me.sts11.UseVisualStyleBackColor = True
        '
        'ss10
        '
        Me.ss10.AutoSize = True
        Me.ss10.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss10.Location = New System.Drawing.Point(1165, 93)
        Me.ss10.Name = "ss10"
        Me.ss10.Size = New System.Drawing.Size(15, 14)
        Me.ss10.TabIndex = 31
        Me.ss10.UseVisualStyleBackColor = True
        '
        's10
        '
        Me.s10.AutoSize = True
        Me.s10.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s10.Location = New System.Drawing.Point(1056, 93)
        Me.s10.Name = "s10"
        Me.s10.Size = New System.Drawing.Size(15, 14)
        Me.s10.TabIndex = 30
        Me.s10.UseVisualStyleBackColor = True
        '
        'n10
        '
        Me.n10.AutoSize = True
        Me.n10.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n10.Location = New System.Drawing.Point(970, 91)
        Me.n10.Name = "n10"
        Me.n10.Size = New System.Drawing.Size(15, 14)
        Me.n10.TabIndex = 29
        Me.n10.UseVisualStyleBackColor = True
        '
        'ts10
        '
        Me.ts10.AutoSize = True
        Me.ts10.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts10.Location = New System.Drawing.Point(850, 93)
        Me.ts10.Name = "ts10"
        Me.ts10.Size = New System.Drawing.Size(15, 14)
        Me.ts10.TabIndex = 28
        Me.ts10.UseVisualStyleBackColor = True
        '
        'sts10
        '
        Me.sts10.AutoSize = True
        Me.sts10.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts10.Location = New System.Drawing.Point(718, 93)
        Me.sts10.Name = "sts10"
        Me.sts10.Size = New System.Drawing.Size(15, 14)
        Me.sts10.TabIndex = 27
        Me.sts10.UseVisualStyleBackColor = True
        '
        'ss9
        '
        Me.ss9.AutoSize = True
        Me.ss9.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss9.Location = New System.Drawing.Point(1165, 67)
        Me.ss9.Name = "ss9"
        Me.ss9.Size = New System.Drawing.Size(15, 14)
        Me.ss9.TabIndex = 26
        Me.ss9.UseVisualStyleBackColor = True
        '
        's9
        '
        Me.s9.AutoSize = True
        Me.s9.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s9.Location = New System.Drawing.Point(1056, 67)
        Me.s9.Name = "s9"
        Me.s9.Size = New System.Drawing.Size(15, 14)
        Me.s9.TabIndex = 25
        Me.s9.UseVisualStyleBackColor = True
        '
        'n9
        '
        Me.n9.AutoSize = True
        Me.n9.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n9.Location = New System.Drawing.Point(970, 65)
        Me.n9.Name = "n9"
        Me.n9.Size = New System.Drawing.Size(15, 14)
        Me.n9.TabIndex = 24
        Me.n9.UseVisualStyleBackColor = True
        '
        'ts9
        '
        Me.ts9.AutoSize = True
        Me.ts9.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts9.Location = New System.Drawing.Point(850, 67)
        Me.ts9.Name = "ts9"
        Me.ts9.Size = New System.Drawing.Size(15, 14)
        Me.ts9.TabIndex = 23
        Me.ts9.UseVisualStyleBackColor = True
        '
        'sts9
        '
        Me.sts9.AutoSize = True
        Me.sts9.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts9.Location = New System.Drawing.Point(718, 67)
        Me.sts9.Name = "sts9"
        Me.sts9.Size = New System.Drawing.Size(15, 14)
        Me.sts9.TabIndex = 22
        Me.sts9.UseVisualStyleBackColor = True
        '
        'ss8
        '
        Me.ss8.AutoSize = True
        Me.ss8.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss8.Location = New System.Drawing.Point(1165, 43)
        Me.ss8.Name = "ss8"
        Me.ss8.Size = New System.Drawing.Size(15, 14)
        Me.ss8.TabIndex = 21
        Me.ss8.UseVisualStyleBackColor = True
        '
        's8
        '
        Me.s8.AutoSize = True
        Me.s8.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s8.Location = New System.Drawing.Point(1056, 43)
        Me.s8.Name = "s8"
        Me.s8.Size = New System.Drawing.Size(15, 14)
        Me.s8.TabIndex = 20
        Me.s8.UseVisualStyleBackColor = True
        '
        'n8
        '
        Me.n8.AutoSize = True
        Me.n8.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n8.Location = New System.Drawing.Point(970, 41)
        Me.n8.Name = "n8"
        Me.n8.Size = New System.Drawing.Size(15, 14)
        Me.n8.TabIndex = 19
        Me.n8.UseVisualStyleBackColor = True
        '
        'ts8
        '
        Me.ts8.AutoSize = True
        Me.ts8.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts8.Location = New System.Drawing.Point(850, 43)
        Me.ts8.Name = "ts8"
        Me.ts8.Size = New System.Drawing.Size(15, 14)
        Me.ts8.TabIndex = 18
        Me.ts8.UseVisualStyleBackColor = True
        '
        'sts8
        '
        Me.sts8.AutoSize = True
        Me.sts8.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts8.Location = New System.Drawing.Point(718, 43)
        Me.sts8.Name = "sts8"
        Me.sts8.Size = New System.Drawing.Size(15, 14)
        Me.sts8.TabIndex = 17
        Me.sts8.UseVisualStyleBackColor = True
        '
        'ss7
        '
        Me.ss7.AutoSize = True
        Me.ss7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ss7.Location = New System.Drawing.Point(1165, 16)
        Me.ss7.Name = "ss7"
        Me.ss7.Size = New System.Drawing.Size(15, 14)
        Me.ss7.TabIndex = 16
        Me.ss7.UseVisualStyleBackColor = True
        '
        's7
        '
        Me.s7.AutoSize = True
        Me.s7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.s7.Location = New System.Drawing.Point(1056, 16)
        Me.s7.Name = "s7"
        Me.s7.Size = New System.Drawing.Size(15, 14)
        Me.s7.TabIndex = 15
        Me.s7.UseVisualStyleBackColor = True
        '
        'n7
        '
        Me.n7.AutoSize = True
        Me.n7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.n7.Location = New System.Drawing.Point(970, 14)
        Me.n7.Name = "n7"
        Me.n7.Size = New System.Drawing.Size(15, 14)
        Me.n7.TabIndex = 14
        Me.n7.UseVisualStyleBackColor = True
        '
        'ts7
        '
        Me.ts7.AutoSize = True
        Me.ts7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ts7.Location = New System.Drawing.Point(850, 16)
        Me.ts7.Name = "ts7"
        Me.ts7.Size = New System.Drawing.Size(15, 14)
        Me.ts7.TabIndex = 13
        Me.ts7.UseVisualStyleBackColor = True
        '
        'sts7
        '
        Me.sts7.AutoSize = True
        Me.sts7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.sts7.Location = New System.Drawing.Point(718, 16)
        Me.sts7.Name = "sts7"
        Me.sts7.Size = New System.Drawing.Size(15, 14)
        Me.sts7.TabIndex = 12
        Me.sts7.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 139)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(478, 13)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "6. Koordinator / Laboran / Aslab, bersikap ramah dan menyenangkan dalam memberika" & _
            "n pelayanan" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(6, 114)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(247, 13)
        Me.Label13.TabIndex = 5
        Me.Label13.Text = "5. Koordinator / Laboran / Aslab, mudah dihubungi" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(7, 91)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(370, 13)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = "4. Kemudahan untuk menyampaikan masalah yang berhubungan dengan lab" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(7, 67)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(327, 13)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "3. Kemudahan untuk mendapatkan informasi mengenai laboratorium" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(16, 67)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(45, 13)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Label10"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(7, 41)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(233, 26)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "2. Kebersihan Laboratorium terjaga dengan baik" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(7, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(298, 26)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "1. Kemudahan penggunaan Laboratorium di luar jadwal kuliah" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(704, 69)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(123, 13)
        Me.Label15.TabIndex = 4
        Me.Label15.Text = "Sangat Tidak Setuju"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(857, 69)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(79, 13)
        Me.Label16.TabIndex = 5
        Me.Label16.Text = "Tidak Setuju"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(993, 69)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(41, 13)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "Netral"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(1079, 69)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(43, 13)
        Me.Label18.TabIndex = 7
        Me.Label18.Text = "Setuju"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(1166, 69)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(87, 13)
        Me.Label19.TabIndex = 8
        Me.Label19.Text = "Sangat Setuju"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(587, 548)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(138, 60)
        Me.Button1.TabIndex = 9
        Me.Button1.Text = "KIRIM"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'semester
        '
        Me.semester.Location = New System.Drawing.Point(56, 50)
        Me.semester.Name = "semester"
        Me.semester.Size = New System.Drawing.Size(100, 20)
        Me.semester.TabIndex = 10
        Me.semester.Visible = False
        '
        'Kuisioner
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1337, 673)
        Me.ControlBox = False
        Me.Controls.Add(Me.semester)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Layanan)
        Me.Controls.Add(Me.Fasilitas)
        Me.Controls.Add(Me.Akademik)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Kuisioner"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Kuisioner"
        Me.TopMost = True
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Akademik.ResumeLayout(False)
        Me.Akademik.PerformLayout()
        Me.Fasilitas.ResumeLayout(False)
        Me.Fasilitas.PerformLayout()
        Me.Layanan.ResumeLayout(False)
        Me.Layanan.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Akademik As System.Windows.Forms.GroupBox
    Friend WithEvents sts1 As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Fasilitas As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Layanan As System.Windows.Forms.GroupBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents ss1 As System.Windows.Forms.CheckBox
    Friend WithEvents s1 As System.Windows.Forms.CheckBox
    Friend WithEvents n1 As System.Windows.Forms.CheckBox
    Friend WithEvents ts1 As System.Windows.Forms.CheckBox
    Friend WithEvents ss2 As System.Windows.Forms.CheckBox
    Friend WithEvents s2 As System.Windows.Forms.CheckBox
    Friend WithEvents n2 As System.Windows.Forms.CheckBox
    Friend WithEvents ts2 As System.Windows.Forms.CheckBox
    Friend WithEvents sts2 As System.Windows.Forms.CheckBox
    Friend WithEvents ss6 As System.Windows.Forms.CheckBox
    Friend WithEvents s6 As System.Windows.Forms.CheckBox
    Friend WithEvents n6 As System.Windows.Forms.CheckBox
    Friend WithEvents ts6 As System.Windows.Forms.CheckBox
    Friend WithEvents sts6 As System.Windows.Forms.CheckBox
    Friend WithEvents ss5 As System.Windows.Forms.CheckBox
    Friend WithEvents s5 As System.Windows.Forms.CheckBox
    Friend WithEvents n5 As System.Windows.Forms.CheckBox
    Friend WithEvents ts5 As System.Windows.Forms.CheckBox
    Friend WithEvents sts5 As System.Windows.Forms.CheckBox
    Friend WithEvents ss4 As System.Windows.Forms.CheckBox
    Friend WithEvents s4 As System.Windows.Forms.CheckBox
    Friend WithEvents n4 As System.Windows.Forms.CheckBox
    Friend WithEvents ts4 As System.Windows.Forms.CheckBox
    Friend WithEvents sts4 As System.Windows.Forms.CheckBox
    Friend WithEvents ss3 As System.Windows.Forms.CheckBox
    Friend WithEvents s3 As System.Windows.Forms.CheckBox
    Friend WithEvents n3 As System.Windows.Forms.CheckBox
    Friend WithEvents ts3 As System.Windows.Forms.CheckBox
    Friend WithEvents sts3 As System.Windows.Forms.CheckBox
    Friend WithEvents ss12 As System.Windows.Forms.CheckBox
    Friend WithEvents s12 As System.Windows.Forms.CheckBox
    Friend WithEvents n12 As System.Windows.Forms.CheckBox
    Friend WithEvents ts12 As System.Windows.Forms.CheckBox
    Friend WithEvents sts12 As System.Windows.Forms.CheckBox
    Friend WithEvents ss11 As System.Windows.Forms.CheckBox
    Friend WithEvents s11 As System.Windows.Forms.CheckBox
    Friend WithEvents n11 As System.Windows.Forms.CheckBox
    Friend WithEvents ts11 As System.Windows.Forms.CheckBox
    Friend WithEvents sts11 As System.Windows.Forms.CheckBox
    Friend WithEvents ss10 As System.Windows.Forms.CheckBox
    Friend WithEvents s10 As System.Windows.Forms.CheckBox
    Friend WithEvents n10 As System.Windows.Forms.CheckBox
    Friend WithEvents ts10 As System.Windows.Forms.CheckBox
    Friend WithEvents sts10 As System.Windows.Forms.CheckBox
    Friend WithEvents ss9 As System.Windows.Forms.CheckBox
    Friend WithEvents s9 As System.Windows.Forms.CheckBox
    Friend WithEvents n9 As System.Windows.Forms.CheckBox
    Friend WithEvents ts9 As System.Windows.Forms.CheckBox
    Friend WithEvents sts9 As System.Windows.Forms.CheckBox
    Friend WithEvents ss8 As System.Windows.Forms.CheckBox
    Friend WithEvents s8 As System.Windows.Forms.CheckBox
    Friend WithEvents n8 As System.Windows.Forms.CheckBox
    Friend WithEvents ts8 As System.Windows.Forms.CheckBox
    Friend WithEvents sts8 As System.Windows.Forms.CheckBox
    Friend WithEvents ss7 As System.Windows.Forms.CheckBox
    Friend WithEvents s7 As System.Windows.Forms.CheckBox
    Friend WithEvents n7 As System.Windows.Forms.CheckBox
    Friend WithEvents ts7 As System.Windows.Forms.CheckBox
    Friend WithEvents sts7 As System.Windows.Forms.CheckBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents semester As System.Windows.Forms.TextBox
End Class
