﻿Imports System.Net

Public Class Setup

    Private Sub savesetno_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles savesetno.Click
        Dim strINIFile As String = Application.StartupPath + "\Config.ini"
        SetIniSettings(strINIFile, "Setting", "Server", setipserver.Text)
        SetIniSettings(strINIFile, "Setting", "NoIP", setipkomputer.Text)
        SetIniSettings(strINIFile, "Setting", "Lab", setlab.Text)
        SetIniSettings(strINIFile, "Setting", "NoKomputer", setno.Text)
        MsgBox("Aplikasi Akan di Restart untuk menjalankan Perubahan. Klik Ok dan Jalankan Ulang Program", MsgBoxStyle.Information)
        Main.cek()
        Application.Restart()
    End Sub
    Private Sub Setup_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class