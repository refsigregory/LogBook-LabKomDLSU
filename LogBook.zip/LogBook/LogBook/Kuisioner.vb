﻿Imports MySql.Data.MySqlClient
Imports Microsoft.Win32
Imports System.Diagnostics
Imports System.Runtime.InteropServices
Imports System.Data.SqlClient
Imports System.Threading

Public Class Kuisioner
    Dim koneksi As New MySqlConnection
    Public da As MySqlDataAdapter
    Public dt As DataTable
    Public ds As DataSet
    Public cd As MySqlCommand
    Public rd As MySqlDataReader
    Dim stringkoneksi As String = "Server=" + conf_server + ";User Id=" + conf_userdb + ";Password=" + conf_passdb + ";Database=" + conf_dbname + ""
    Dim perintahmysql As New MySqlCommand
    Dim perintahsql As New SqlCommand
    Public time As String = Format(Now, "dd/MM/yyyy HH:mm:ss")
    Sub koneksi2()
        koneksi.ConnectionString = stringkoneksi
        Try
            If koneksi.State = ConnectionState.Closed Then
                koneksi.Open()
            Else
                koneksi.Close()
            End If
        Catch ex As Exception
            Dim pilihankoneksi As String = MsgBox("Koneksi Gagal, Hubungi Aslab!", vbCritical + vbRetryCancel, "Koneksi Gagal")
            If pilihankoneksi = vbRetry Then
                Application.Restart()
            Else

            End If
        End Try

    End Sub
    Sub perintah(ByVal kirim As String)
        With perintahmysql
            .CommandText = kirim
            .CommandType = CommandType.Text
            .Connection = koneksi
            .ExecuteNonQuery()
        End With
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (sts1.Text <> "") Or (ts1.Text <> "") Or (n1.Text <> "") Or (s1.Text <> "") Or (ss1.Text <> "") And (sts2.Text <> "") Or (ts2.Text <> "") Or (n2.Text <> "") Or (s2.Text <> "") Or (ss2.Text <> "") And (sts3.Text <> "") Or (ts3.Text <> "") Or (n3.Text <> "") Or (s3.Text <> "") Or (ss3.Text <> "") And (sts4.Text <> "") Or (ts4.Text <> "") Or (n4.Text <> "") Or (s4.Text <> "") Or (ss4.Text <> "") And (sts5.Text <> "") Or (ts5.Text <> "") Or (n5.Text <> "") Or (s5.Text <> "") Or (ss5.Text <> "") And (sts6.Text <> "") Or (ts6.Text <> "") Or (n6.Text <> "") Or (s6.Text <> "") Or (ss6.Text <> "") And (sts7.Text <> "") Or (ts7.Text <> "") Or (n7.Text <> "") Or (s7.Text <> "") Or (ss7.Text <> "") And (sts8.Text <> "") Or (ts8.Text <> "") Or (n8.Text <> "") Or (s8.Text <> "") Or (ss8.Text <> "") And (sts9.Text <> "") Or (ts9.Text <> "") Or (n9.Text <> "") Or (s9.Text <> "") Or (ss9.Text <> "") And (sts10.Text <> "") Or (ts10.Text <> "") Or (n10.Text <> "") Or (s10.Text <> "") Or (ss10.Text <> "") And (sts11.Text <> "") Or (ts11.Text <> "") Or (n11.Text <> "") Or (s11.Text <> "") Or (ss11.Text <> "") And (sts12.Text <> "") Or (ts12.Text <> "") Or (n12.Text <> "") Or (s12.Text <> "") Or (ss12.Text <> "") Then
            Dim kalimatmysql1 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '1','" + semester.Text + "', '" + sts1.Text + "', '" + ts1.Text + "', '" + n1.Text + "', '" + s1.Text + "', '" & ss1.Text & "')"
            perintah(kalimatmysql1)
            Dim kalimatmysql2 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '2','" + semester.Text + "', '" + sts2.Text + "', '" + ts2.Text + "', '" + n2.Text + "', '" + s2.Text + "', '" & ss2.Text & "')"
            perintah(kalimatmysql2)
            Dim kalimatmysql3 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '3','" + semester.Text + "', '" + sts3.Text + "', '" + ts3.Text + "', '" + n3.Text + "', '" + s3.Text + "', '" & ss3.Text & "')"
            perintah(kalimatmysql3)
            Dim kalimatmysql4 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '4','" + semester.Text + "', '" + sts4.Text + "', '" + ts4.Text + "', '" + n4.Text + "', '" + s4.Text + "', '" & ss4.Text & "')"
            perintah(kalimatmysql4)
            Dim kalimatmysql5 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '5','" + semester.Text + "', '" + sts5.Text + "', '" + ts5.Text + "', '" + n5.Text + "', '" + s5.Text + "', '" & ss5.Text & "')"
            perintah(kalimatmysql5)
            Dim kalimatmysql6 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '6','" + semester.Text + "', '" + sts6.Text + "', '" + ts6.Text + "', '" + n6.Text + "', '" + s6.Text + "', '" & ss6.Text & "')"
            perintah(kalimatmysql6)
            Dim kalimatmysql7 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '7','" + semester.Text + "', '" + sts7.Text + "', '" + ts7.Text + "', '" + n7.Text + "', '" + s7.Text + "', '" & ss7.Text & "')"
            perintah(kalimatmysql7)
            Dim kalimatmysql8 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '8','" + semester.Text + "', '" + sts8.Text + "', '" + ts8.Text + "', '" + n8.Text + "', '" + s8.Text + "', '" & ss8.Text & "')"
            perintah(kalimatmysql8)
            Dim kalimatmysql9 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '9','" + semester.Text + "', '" + sts9.Text + "', '" + ts9.Text + "', '" + n9.Text + "', '" + s9.Text + "', '" & ss9.Text & "')"
            perintah(kalimatmysql9)
            Dim kalimatmysql10 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '10','" + semester.Text + "', '" + sts10.Text + "', '" + ts10.Text + "', '" + n10.Text + "', '" + s10.Text + "', '" & ss10.Text & "')"
            perintah(kalimatmysql10)
            Dim kalimatmysql11 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '11','" + semester.Text + "', '" + sts11.Text + "', '" + ts11.Text + "', '" + n11.Text + "', '" + s11.Text + "', '" & ss11.Text & "')"
            perintah(kalimatmysql11)
            Dim kalimatmysql12 As String = "insert into `kuisioner` (`nim`,`no`,`semester`,`sts`,`ts`,`n`,`s`,`ss`) values ('" + Main.nim.Text + "', '12','" + semester.Text + "', '" + sts12.Text + "', '" + ts12.Text + "', '" + n12.Text + "', '" + s12.Text + "', '" & ss12.Text & "')"
            perintah(kalimatmysql12)
            Me.Hide()
        Else
            MsgBox("Harap Mengisi Semua Pertanyaan!", MsgBoxStyle.Exclamation)
        End If

    End Sub

    Private Sub Kuisioner_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksi2()
        MsgBox("Demi Kemajuan Lab " & Main.lab & " isilah Kuisioner berikut ini dengan benar.", vbInformation, "Kuisioner")

    End Sub

    Private Sub n1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n1.CheckedChanged
        n1.Text = 1
    End Sub

    Private Sub sts1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts1.CheckedChanged
        sts1.Text = 1
    End Sub

    Private Sub ts1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts1.CheckedChanged
        ts11.Text = 1
    End Sub

    Private Sub s1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s1.CheckedChanged
        s1.Text = 1
    End Sub

    Private Sub ss1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss1.CheckedChanged
        ss1.Text = 1
    End Sub

    Private Sub sts2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts2.CheckedChanged
        sts2.Text = 1
    End Sub

    Private Sub ts2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts2.CheckedChanged
        ts2.Text = 1
    End Sub

    Private Sub n2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n2.CheckedChanged
        n2.Text = 1
    End Sub

    Private Sub s2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s2.CheckedChanged
        s2.Text = 1
    End Sub

    Private Sub ss2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss2.CheckedChanged
        ss2.Text = 1
    End Sub

    Private Sub sts3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts3.CheckedChanged
        sts3.Text = 1
    End Sub

    Private Sub ts3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts3.CheckedChanged
        ts3.Text = 1
    End Sub

    Private Sub n3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n3.CheckedChanged
        n3.Text = 1
    End Sub

    Private Sub s3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s3.CheckedChanged
        s3.Text = 1
    End Sub

    Private Sub ss3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss3.CheckedChanged
        ss3.Text = 1
    End Sub

    Private Sub sts4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts4.CheckedChanged
        sts4.Text = 1
    End Sub

    Private Sub ts4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts4.CheckedChanged
        ts4.Text = 1
    End Sub

    Private Sub n4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n4.CheckedChanged
        n4.Text = 1
    End Sub

    Private Sub s4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s4.CheckedChanged
        s4.Text = 1
    End Sub

    Private Sub ss4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss4.CheckedChanged
        ss4.Text = 1
    End Sub

    Private Sub sts5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts5.CheckedChanged
        sts5.Text = 1
    End Sub

    Private Sub ts5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts5.CheckedChanged
        ts5.Text = 1
    End Sub

    Private Sub n5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n5.CheckedChanged
        n5.Text = 1
    End Sub

    Private Sub s5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s5.CheckedChanged
        s5.Text = 1
    End Sub

    Private Sub ss5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss5.CheckedChanged
        ss5.Text = 1
    End Sub

    Private Sub sts6_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts6.CheckedChanged
        sts6.Text = 1
    End Sub

    Private Sub ts6_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts6.CheckedChanged
        ts6.Text = 1
    End Sub

    Private Sub n6_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n6.CheckedChanged
        n6.Text = 1
    End Sub

    Private Sub s6_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s6.CheckedChanged
        s6.Text = 1
    End Sub

    Private Sub ss6_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss6.CheckedChanged
        ss6.Text = 1
    End Sub

    Private Sub sts7_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts7.CheckedChanged
        sts7.Text = 1
    End Sub

    Private Sub ts7_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts7.CheckedChanged
        ts7.Text = 1
    End Sub

    Private Sub s7_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s7.CheckedChanged
        s7.Text = 1
    End Sub
    Private Sub n7_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n7.CheckedChanged
        n7.Text = 1
    End Sub

    Private Sub ss7_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss7.CheckedChanged
        ss7.Text = 1
    End Sub

    Private Sub ss8_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss8.CheckedChanged
        ss8.Text = 1
    End Sub

    Private Sub n8_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n8.CheckedChanged
        n8.Text = 1
    End Sub

    Private Sub s8_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s8.CheckedChanged
        s8.Text = 1
    End Sub

    Private Sub sts8_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts8.CheckedChanged
        sts8.Text = 1
    End Sub

    Private Sub ts11_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts11.CheckedChanged
        ts11.Text = 1
    End Sub

    Private Sub ts12_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts12.CheckedChanged
        ts12.Text = 1
    End Sub

    Private Sub sts11_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts11.CheckedChanged
        sts11.Text = 1
    End Sub

    Private Sub sts12_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts12.CheckedChanged
        sts12.Text = 1
    End Sub

    Private Sub n12_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n12.CheckedChanged
        n12.Text = 1
    End Sub

    Private Sub n11_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n11.CheckedChanged
        n11.Text = 1
    End Sub

    Private Sub s11_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s11.CheckedChanged
        s11.Text = 1
    End Sub

    Private Sub s12_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s12.CheckedChanged
        s12.Text = 1
    End Sub

    Private Sub ss12_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss12.CheckedChanged
        ss12.Text = 1
    End Sub

    Private Sub ss11_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss11.CheckedChanged
        ss11.Text = 1
    End Sub

    Private Sub ss10_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss10.CheckedChanged
        ss10.Text = 1
    End Sub

    Private Sub s10_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s10.CheckedChanged
        s10.Text = 1
    End Sub

    Private Sub n10_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n10.CheckedChanged
        n10.Text = 1
    End Sub

    Private Sub ts10_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts10.CheckedChanged
        ts10.Text = 1
    End Sub

    Private Sub sts10_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts10.CheckedChanged
        sts10.Text = 1
    End Sub

    Private Sub ss9_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ss9.CheckedChanged
        ss9.Text = 1
    End Sub

    Private Sub s9_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles s9.CheckedChanged
        s9.Text = 1
    End Sub

    Private Sub n9_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles n9.CheckedChanged
        n9.Text = 1
    End Sub

    Private Sub ts9_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts9.CheckedChanged
        ts9.Text = 1
    End Sub

    Private Sub sts9_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sts9.CheckedChanged
        sts9.Text = 1
    End Sub
End Class