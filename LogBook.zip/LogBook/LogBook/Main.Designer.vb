﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.nim = New System.Windows.Forms.TextBox()
        Me.nama = New System.Windows.Forms.TextBox()
        Me.login = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.text_berjalan = New System.Windows.Forms.Label()
        Me.namalab = New System.Windows.Forms.Label()
        Me.tujuan = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.statuskoneksi = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.logo_main = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.nokomputer = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Credit = New System.Windows.Forms.Label()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.peraturan_text = New System.Windows.Forms.Label()
        Me.judul_peraturan_box = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripDropDownButton1 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.KofigurasiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TutupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.shutdown = New System.Windows.Forms.ToolStripDropDownButton()
        Me.shutdown_button = New System.Windows.Forms.ToolStripMenuItem()
        Me.restart_button = New System.Windows.Forms.ToolStripMenuItem()
        Me.MetroStyleManager1 = New MetroFramework.Components.MetroStyleManager(Me.components)
        Me.Timer_text_berjalan = New System.Windows.Forms.Timer(Me.components)
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.TimerUpdate = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        CType(Me.logo_main, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.MetroStyleManager1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'nim
        '
        Me.nim.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.nim.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.nim.BackColor = System.Drawing.SystemColors.Window
        Me.nim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.nim.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nim.ForeColor = System.Drawing.SystemColors.InfoText
        Me.nim.Location = New System.Drawing.Point(465, 135)
        Me.nim.Multiline = True
        Me.nim.Name = "nim"
        Me.nim.Size = New System.Drawing.Size(408, 32)
        Me.nim.TabIndex = 0
        Me.nim.Text = "NIM Mahasiswa"
        '
        'nama
        '
        Me.nama.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.nama.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.nama.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.nama.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nama.ForeColor = System.Drawing.SystemColors.InfoText
        Me.nama.Location = New System.Drawing.Point(465, 186)
        Me.nama.Multiline = True
        Me.nama.Name = "nama"
        Me.nama.Size = New System.Drawing.Size(408, 29)
        Me.nama.TabIndex = 1
        Me.nama.Text = "Nama Mahasiswa"
        '
        'login
        '
        Me.login.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.login.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.login.AutoSize = True
        Me.login.BackColor = System.Drawing.Color.White
        Me.login.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.login.ForeColor = System.Drawing.Color.Black
        Me.login.Location = New System.Drawing.Point(465, 322)
        Me.login.Name = "login"
        Me.login.Size = New System.Drawing.Size(408, 44)
        Me.login.TabIndex = 3
        Me.login.Text = "Masuk"
        Me.login.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.text_berjalan)
        Me.Panel1.Controls.Add(Me.namalab)
        Me.Panel1.Controls.Add(Me.tujuan)
        Me.Panel1.Controls.Add(Me.login)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.nama)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.statuskoneksi)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.nim)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.logo_main)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Location = New System.Drawing.Point(32, 169)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(911, 464)
        Me.Panel1.TabIndex = 4
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(751, 37)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(147, 58)
        Me.Button2.TabIndex = 14
        Me.Button2.Text = "RESTART"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'text_berjalan
        '
        Me.text_berjalan.AutoSize = True
        Me.text_berjalan.Location = New System.Drawing.Point(417, 45)
        Me.text_berjalan.Name = "text_berjalan"
        Me.text_berjalan.Size = New System.Drawing.Size(69, 13)
        Me.text_berjalan.TabIndex = 17
        Me.text_berjalan.Text = "Text Berjalan"
        Me.text_berjalan.Visible = False
        '
        'namalab
        '
        Me.namalab.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.namalab.AutoSize = True
        Me.namalab.Font = New System.Drawing.Font("Impact", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.namalab.ForeColor = System.Drawing.SystemColors.InfoText
        Me.namalab.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.namalab.Location = New System.Drawing.Point(58, 286)
        Me.namalab.Name = "namalab"
        Me.namalab.Size = New System.Drawing.Size(369, 39)
        Me.namalab.TabIndex = 16
        Me.namalab.Text = "Laboratorium Multimedia"
        Me.namalab.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'tujuan
        '
        Me.tujuan.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.tujuan.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tujuan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tujuan.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tujuan.ForeColor = System.Drawing.SystemColors.InfoText
        Me.tujuan.Location = New System.Drawing.Point(465, 234)
        Me.tujuan.Multiline = True
        Me.tujuan.Name = "tujuan"
        Me.tujuan.Size = New System.Drawing.Size(408, 82)
        Me.tujuan.TabIndex = 2
        Me.tujuan.Text = "Tujuan Penggunaan"
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Impact", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Label1.Location = New System.Drawing.Point(155, 247)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(147, 39)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "LOG BOOK"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(22, 14)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(109, 22)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Komputer:"
        Me.Label6.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(748, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 17)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Server:"
        '
        'statuskoneksi
        '
        Me.statuskoneksi.AutoSize = True
        Me.statuskoneksi.Font = New System.Drawing.Font("Arial Narrow", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.statuskoneksi.Location = New System.Drawing.Point(809, 14)
        Me.statuskoneksi.Name = "statuskoneksi"
        Me.statuskoneksi.Size = New System.Drawing.Size(92, 20)
        Me.statuskoneksi.TabIndex = 7
        Me.statuskoneksi.Text = "Disconnected"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(471, 238)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Nama"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(471, 187)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(27, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "NIM"
        '
        'logo_main
        '
        Me.logo_main.Image = CType(resources.GetObject("logo_main.Image"), System.Drawing.Image)
        Me.logo_main.Location = New System.Drawing.Point(174, 150)
        Me.logo_main.Name = "logo_main"
        Me.logo_main.Size = New System.Drawing.Size(117, 94)
        Me.logo_main.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.logo_main.TabIndex = 9
        Me.logo_main.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(471, 286)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Tujuan"
        '
        'nokomputer
        '
        Me.nokomputer.AutoSize = True
        Me.nokomputer.Font = New System.Drawing.Font("Arial Black", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nokomputer.Location = New System.Drawing.Point(12, -3)
        Me.nokomputer.Name = "nokomputer"
        Me.nokomputer.Size = New System.Drawing.Size(623, 90)
        Me.nokomputer.TabIndex = 15
        Me.nokomputer.Text = "RefsiSangkay-01"
        Me.nokomputer.Visible = False
        '
        'Timer1
        '
        '
        'Credit
        '
        Me.Credit.AutoSize = True
        Me.Credit.Font = New System.Drawing.Font("Lucida Sans", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Credit.Location = New System.Drawing.Point(12, 745)
        Me.Credit.Name = "Credit"
        Me.Credit.Size = New System.Drawing.Size(380, 23)
        Me.Credit.TabIndex = 7
        Me.Credit.Text = "© 2016 Created by Refsi Sangkay."
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.AutoSize = True
        Me.Panel2.BackColor = System.Drawing.SystemColors.Window
        Me.Panel2.Controls.Add(Me.peraturan_text)
        Me.Panel2.Controls.Add(Me.judul_peraturan_box)
        Me.Panel2.Location = New System.Drawing.Point(979, 126)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(265, 181)
        Me.Panel2.TabIndex = 8
        Me.Panel2.Visible = False
        '
        'peraturan_text
        '
        Me.peraturan_text.AutoSize = True
        Me.peraturan_text.BackColor = System.Drawing.SystemColors.Window
        Me.peraturan_text.Location = New System.Drawing.Point(13, 43)
        Me.peraturan_text.Name = "peraturan_text"
        Me.peraturan_text.Size = New System.Drawing.Size(53, 13)
        Me.peraturan_text.TabIndex = 1
        Me.peraturan_text.Text = "Peraturan"
        '
        'judul_peraturan_box
        '
        Me.judul_peraturan_box.AutoSize = True
        Me.judul_peraturan_box.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.judul_peraturan_box.Location = New System.Drawing.Point(13, 18)
        Me.judul_peraturan_box.Name = "judul_peraturan_box"
        Me.judul_peraturan_box.Size = New System.Drawing.Size(105, 16)
        Me.judul_peraturan_box.TabIndex = 0
        Me.judul_peraturan_box.Text = "Peraturan Lab"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.GripMargin = New System.Windows.Forms.Padding(10)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripDropDownButton1, Me.shutdown})
        Me.ToolStrip1.Location = New System.Drawing.Point(845, 726)
        Me.ToolStrip1.Margin = New System.Windows.Forms.Padding(20)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(187, 25)
        Me.ToolStrip1.Stretch = True
        Me.ToolStrip1.TabIndex = 10
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripDropDownButton1
        '
        Me.ToolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripDropDownButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.KofigurasiToolStripMenuItem, Me.TutupToolStripMenuItem})
        Me.ToolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton1.Name = "ToolStripDropDownButton1"
        Me.ToolStripDropDownButton1.Size = New System.Drawing.Size(62, 22)
        Me.ToolStripDropDownButton1.Text = "Options"
        Me.ToolStripDropDownButton1.ToolTipText = "Options"
        '
        'KofigurasiToolStripMenuItem
        '
        Me.KofigurasiToolStripMenuItem.Name = "KofigurasiToolStripMenuItem"
        Me.KofigurasiToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.KofigurasiToolStripMenuItem.Text = "Kofigurasi"
        '
        'TutupToolStripMenuItem
        '
        Me.TutupToolStripMenuItem.Name = "TutupToolStripMenuItem"
        Me.TutupToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.TutupToolStripMenuItem.Text = "Keluar"
        '
        'shutdown
        '
        Me.shutdown.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.shutdown.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.shutdown_button, Me.restart_button})
        Me.shutdown.Image = CType(resources.GetObject("shutdown.Image"), System.Drawing.Image)
        Me.shutdown.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.shutdown.Name = "shutdown"
        Me.shutdown.Size = New System.Drawing.Size(74, 22)
        Me.shutdown.Text = "Shutdown"
        Me.shutdown.ToolTipText = "Shutdown"
        '
        'shutdown_button
        '
        Me.shutdown_button.Name = "shutdown_button"
        Me.shutdown_button.Size = New System.Drawing.Size(117, 22)
        Me.shutdown_button.Text = "Matikan"
        '
        'restart_button
        '
        Me.restart_button.Name = "restart_button"
        Me.restart_button.Size = New System.Drawing.Size(117, 22)
        Me.restart_button.Text = "Restart"
        '
        'MetroStyleManager1
        '
        Me.MetroStyleManager1.Owner = Nothing
        '
        'Timer_text_berjalan
        '
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Location = New System.Drawing.Point(466, 697)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(169, 42)
        Me.WebBrowser1.TabIndex = 11
        Me.WebBrowser1.Visible = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(640, 726)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(100, 23)
        Me.ProgressBar1.TabIndex = 12
        Me.ProgressBar1.Visible = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(640, 697)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(61, 23)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'TimerUpdate
        '
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1024, 780)
        Me.ControlBox = False
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.nokomputer)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Credit)
        Me.Controls.Add(Me.Panel1)
        Me.ForeColor = System.Drawing.Color.Black
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Main"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login"
        Me.TopMost = True
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.logo_main, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        CType(Me.MetroStyleManager1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents nim As System.Windows.Forms.TextBox
    Friend WithEvents nama As System.Windows.Forms.TextBox
    Friend WithEvents login As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents tujuan As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents logo_main As System.Windows.Forms.PictureBox
    Friend WithEvents statuskoneksi As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents nokomputer As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Credit As System.Windows.Forms.Label
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents namalab As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents peraturan_text As System.Windows.Forms.Label
    Friend WithEvents judul_peraturan_box As System.Windows.Forms.Label
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripDropDownButton1 As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents KofigurasiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TutupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents shutdown As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents shutdown_button As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents restart_button As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents MetroStyleManager1 As MetroFramework.Components.MetroStyleManager
    Friend WithEvents text_berjalan As System.Windows.Forms.Label
    Friend WithEvents Timer_text_berjalan As System.Windows.Forms.Timer
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents TimerUpdate As System.Windows.Forms.Timer
End Class
