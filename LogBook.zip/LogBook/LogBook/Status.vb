﻿Imports MySql.Data.MySqlClient
Imports Microsoft.Win32
Imports System.Diagnostics
Imports System.Runtime.InteropServices
Imports System.Data.SqlClient
Imports System.Threading

Public Class Status
    Dim actclose As String
    Dim koneksi As New MySqlConnection
    Dim stringkoneksi As String = "Server=" + conf_server + ";User Id=" + conf_userdb + ";Password=" + conf_passdb + ";Database=" + conf_dbname + ""
    Dim perintahmysql As New MySqlCommand
    Dim cmd As New MySqlCommand
    Dim dr As MySqlDataReader
    Dim perintahsql As New SqlCommand
    Public Timer As New Timers.Timer(1000) '1000 ms
    Public tanggal As String = Format(Now, "yyyy-MM-dd")
    Public time As String = Format(Now, "dd/MM/yyyy HH:mm:ss")
    Sub DbConn()
        Try
            If koneksi Is Nothing Or Not koneksi.State = ConnectionState.Open Then 'jika tidak ada koneksi atau koneksi mysql tidak dibuka
                koneksi = New MySqlConnection(stringkoneksi)
                'membuka koneksi mysql
                koneksi.Open()
                status_koneksistatus.Text = "Connected"
                status_koneksistatus.ForeColor = Color.Green
            Else
                koneksi.Close()
                koneksi = New MySqlConnection(stringkoneksi)
                'membuka koneksi mysql
                koneksi.Open()
                status_koneksistatus.Text = "Connected"
                ForeColor = Color.Green
            End If
        Catch ex As Exception
            If status_koneksistatus.Text <> "Disconnected" Then
                status_koneksistatus.Text = "Disconnected"
                status_koneksistatus.ForeColor = Color.Red
            End If

            'Dim pilihankoneksi As String = MsgBox("Koneksi ke Server Gagal, Coba Lagi!", vbInformation + vbOKCancel, "Koneksi Gagal")
            'If pilihankoneksi = vbOK Then
            'Application.Restart()
            'Else
            'End If
        End Try
    End Sub
    Private Sub Status_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Possisi Right Top
        Dim scr = Screen.FromPoint(Me.Location)
        Me.Location = New Point(scr.WorkingArea.Right - Me.Width, scr.WorkingArea.Top)

        UnhookKeyboard()
        ' Start Explorer.exe
        Dim ExProcess = New Process()
        ExProcess.StartInfo.UseShellExecute = True
        ExProcess.StartInfo.CreateNoWindow = True
        ExProcess.StartInfo.FileName = "c:\windows\explorer.exe"
        ExProcess.StartInfo.WorkingDirectory = Application.StartupPath
        ExProcess.Start()

        'Stop Timer Kill
        Main.Timer1.Stop()

        ' Variabel yg ditampilkan
        DbConn()

        cmd = New MySqlCommand("SELECT * FROM `log_list` WHERE id=" & lastid.Text & " and `tanggal`='" + tanggal + "'", koneksi)
        dr = cmd.ExecuteReader
        dr.Read()
        nim.Text = dr.Item("nim")
        nama.Text = dr.Item("nama")
        Dim lab As String = My.Settings.conf_lab
        Dim labs As String = Replace(lab, " ", "")
        komputer.Text = labs + "-" + My.Settings.conf_no
        tujuan.Text = dr.Item("tujuan")
        koneksi.Close()

        ' Wizard
        MsgBox("Setelah Selesai penggunaan jangan lupa menekan tombol SELESAI di Status (Jangan di Shutdown langsung). Jika ada pertanyaan hubungi Aslab.", MsgBoxStyle.Information)

        ' Timer
        Timer.AutoReset = True
        AddHandler Timer.Elapsed, AddressOf TimerElapsedHandler
        Timer.Start()

        'MyBase.OnLoad(e)
    End Sub

    Sub Selesai()
        DbConn()

        Dim keluar As String = Format(Now, "dd/MM/yyyy HH:mm")
        Dim kalimatmysql As String = "update log_list set keluar='" & keluar & "' where id=" & lastid.Text & ""
        perintah(kalimatmysql)
        actclose = "yes"
        Me.Hide()
        Application.Restart()

        koneksi.Close()
    End Sub
    'Event types
    Private Const WM_KEYUP As Integer = &H101
    Private Const WM_KEYDOWN As Short = &H100S
    Private Const WM_SYSKEYDOWN As Integer = &H104
    Private Const WM_SYSKEYUP As Integer = &H105
    'Event Info structure
    Public Structure KBDLLHOOKSTRUCT
        Public vkCode As Integer
        Public scanCode As Integer
        Public flags As Integer
        Public time As Integer
        Public dwExtraInfo As Integer
    End Structure
    'Keyboard hook related functions
    Private Declare Function UnhookWindowsHookEx Lib "user32" (ByVal hHook As Integer) As Integer
    Private Declare Function SetWindowsHookEx Lib "user32" Alias "SetWindowsHookExA" (ByVal idHook As Integer, ByVal lpfn As KeyboardHookDelegate, ByVal hmod As Integer, ByVal dwThreadId As Integer) As Integer
    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Integer) As Integer
    Private Declare Function CallNextHookEx Lib "user32" (ByVal hHook As Integer, ByVal nCode As Integer, ByVal wParam As Integer, ByVal lParam As KBDLLHOOKSTRUCT) As Integer
    Private Delegate Function KeyboardHookDelegate(ByVal Code As Integer, ByVal wParam As Integer, ByRef lParam As KBDLLHOOKSTRUCT) As Integer
    Private KeyboardHandle As IntPtr = 0 'Handle of the hook
    Private callback As KeyboardHookDelegate = Nothing 'Delegate for the hook
    Private Function Hooked()
        Return KeyboardHandle <> 0 'If KeyboardHandle = 0 it means that it isn't hooked so return false, otherwise return true
    End Function
    Public Sub HookKeyboard()
        callback = New KeyboardHookDelegate(AddressOf KeyboardCallback)
        KeyboardHandle = SetWindowsHookEx(13, callback, Process.GetCurrentProcess.MainModule.BaseAddress, 0)
        If KeyboardHandle <> 0 Then
            Debug.Write(vbCrLf & "[Keyboard Hooked]" & vbCrLf)
        End If
    End Sub
    Public Sub UnhookKeyboard()
        If (Hooked()) Then
            If UnhookWindowsHookEx(KeyboardHandle) <> 0 Then
                Debug.Write(vbCrLf & "[Keyboard Unhooked]")
                KeyboardHandle = 0 'We have unhooked successfully
            End If
        End If
    End Sub
    Public Function KeyboardCallback(ByVal Code As Integer, ByVal wParam As Integer, ByRef lParam As KBDLLHOOKSTRUCT) As Integer
        'Variable to hold the text describing the key pressed
        Dim Key = lParam.vkCode
        'If event is KEYDOWN
        If wParam = WM_KEYDOWN Or wParam = WM_SYSKEYDOWN Then
            'If we can block events
            If Code >= 0 Then
                If Key = 91 Or Key = 92 Then
                    Return 1 'Block event
                End If
            End If
        End If
        Debug.Write(Key)
        'Return CallNextHookEx(KeyboardHandle, Code, wParam, lParam) 'Let event go to the other applications
        Return ""
    End Function


    Sub perintah(ByVal kirim As String)
        DbConn()
        With perintahmysql
            .CommandText = kirim
            .CommandType = CommandType.Text
            .Connection = koneksi
            .ExecuteNonQuery()
        End With
        koneksi.Close()
    End Sub

    Private Sub TimerElapsedHandler(ByVal sender As Object, ByVal e As Timers.ElapsedEventArgs)
        DbConn()

        Dim times As String = Format(Now, "yyyy-MM-dd HH:mm:ss")
        Dim kalimatmysql As String = "update log_list set last_active='" & times & "' where id=" & lastid.Text & ""
        perintah(kalimatmysql)

        DbConn()

        cmd = New MySqlCommand("SELECT * FROM `log_list` WHERE id=" & lastid.Text & " and `tanggal`='" + tanggal + "'", koneksi)
        dr = cmd.ExecuteReader
        dr.Read()

        If dr.Item("keluar") <> "" Then
            Selesai()
        End If

        koneksi.Close()
    End Sub
    Private Sub logout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles logout.Click
        If status_koneksistatus.Text = "Disconnected" Then
            Dim pilihankoneksi As String = MsgBox("Koneksi ke Server Log Book Gagal! Pastikan Status koneksi Connected. Jika tidak hubungi Aslab.", vbInformation + vbOKOnly, "Koneksi Gagal")
            If pilihankoneksi = vbOK Then
                'Application.Restart()
            End If
        Else
            Dim yakinkeluar As String = MsgBox("Anda yakin telah selesai menggunakan komputer ini? Tekan OK untuk melanjutkan. ^^", vbOKCancel + vbInformation, "Konfirmasi Keluar")
            If yakinkeluar = vbOK Then
                Selesai()
            End If
        End If
            'If koneksi.State = ConnectionState.Open Then
            'Else

            '    Dim pilihankoneksi As String = MsgBox("Koneksi Gagal, Hubungi Aslab!", vbCritical + vbRetry, "Koneksi Gagal")
            '    If pilihankoneksi = vbRetry Then
            '        Application.Restart()
            '    End If

            'End If

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        update_status.Text = Format(Now, "hh:mm:ss")
    End Sub

    Private Sub Status_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        If Me.WindowState = FormWindowState.Minimized Then
            NotifyIcon1.Visible = True
            Me.Hide()
            NotifyIcon1.BalloonTipText = "Klik disini jika sudah SELESAI"
            NotifyIcon1.ShowBalloonTip(500)
        End If
    End Sub

    Private Sub Status_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If actclose = "yes" Then
            Me.Hide()
        Else
            e.Cancel = True
            NotifyIcon1.Visible = True
            Me.Hide()
            NotifyIcon1.BalloonTipText = "Klik disini jika sudah SELESAI"
            NotifyIcon1.ShowBalloonTip(500)
            'Now make it invisible (make it look like it went into the system tray)
            Me.Visible = False
        End If

    End Sub

    Private Sub NotifyIcon1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NotifyIcon1.Click
        Me.Show()
        Me.WindowState = FormWindowState.Normal
        NotifyIcon1.Visible = False
    End Sub

    Private Sub NotifyIcon1_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles NotifyIcon1.MouseDoubleClick
        If Me.WindowState = FormWindowState.Minimized Then
            NotifyIcon1.Visible = True
            Me.Hide()
            NotifyIcon1.BalloonTipText = "Double Klik disini jika sudah SELESAI"
            NotifyIcon1.ShowBalloonTip(500)
        Else
            Me.Show()
            Me.WindowState = FormWindowState.Normal
            NotifyIcon1.Visible = False
        End If
    End Sub

    Private Sub status_koneksistatus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles status_koneksistatus.Click
        Application.Restart()
    End Sub
End Class