﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Status
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Status))
        Me.nim = New System.Windows.Forms.Label()
        Me.nama = New System.Windows.Forms.Label()
        Me.komputer = New System.Windows.Forms.Label()
        Me.Label_nim = New System.Windows.Forms.Label()
        Me.Label_nama = New System.Windows.Forms.Label()
        Me.logout = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tujuan = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lastid = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.update_status = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.status_koneksistatus = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'nim
        '
        Me.nim.AutoSize = True
        Me.nim.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nim.ForeColor = System.Drawing.SystemColors.InfoText
        Me.nim.Location = New System.Drawing.Point(103, 54)
        Me.nim.Name = "nim"
        Me.nim.Size = New System.Drawing.Size(38, 20)
        Me.nim.TabIndex = 0
        Me.nim.Text = "NIM"
        '
        'nama
        '
        Me.nama.AutoSize = True
        Me.nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nama.ForeColor = System.Drawing.SystemColors.InfoText
        Me.nama.Location = New System.Drawing.Point(103, 32)
        Me.nama.Name = "nama"
        Me.nama.Size = New System.Drawing.Size(51, 20)
        Me.nama.TabIndex = 1
        Me.nama.Text = "Nama"
        '
        'komputer
        '
        Me.komputer.AutoSize = True
        Me.komputer.Font = New System.Drawing.Font("Arial Black", 14.0!, System.Drawing.FontStyle.Bold)
        Me.komputer.ForeColor = System.Drawing.SystemColors.InfoText
        Me.komputer.Location = New System.Drawing.Point(14, 0)
        Me.komputer.Name = "komputer"
        Me.komputer.Size = New System.Drawing.Size(134, 27)
        Me.komputer.TabIndex = 2
        Me.komputer.Text = "Komputer-0"
        Me.komputer.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label_nim
        '
        Me.Label_nim.AutoSize = True
        Me.Label_nim.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label_nim.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label_nim.Location = New System.Drawing.Point(15, 54)
        Me.Label_nim.Name = "Label_nim"
        Me.Label_nim.Size = New System.Drawing.Size(38, 20)
        Me.Label_nim.TabIndex = 3
        Me.Label_nim.Text = "NIM"
        '
        'Label_nama
        '
        Me.Label_nama.AutoSize = True
        Me.Label_nama.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label_nama.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label_nama.Location = New System.Drawing.Point(15, 77)
        Me.Label_nama.Name = "Label_nama"
        Me.Label_nama.Size = New System.Drawing.Size(57, 20)
        Me.Label_nama.TabIndex = 4
        Me.Label_nama.Text = "Tujuan"
        '
        'logout
        '
        Me.logout.AccessibleDescription = "Klik disini jika sudah selesai menggunakan Komputer"
        Me.logout.AccessibleName = "Selesai Penggunaan"
        Me.logout.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.logout.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.logout.ForeColor = System.Drawing.SystemColors.InfoText
        Me.logout.Location = New System.Drawing.Point(24, 100)
        Me.logout.Name = "logout"
        Me.logout.Size = New System.Drawing.Size(240, 59)
        Me.logout.TabIndex = 6
        Me.logout.Text = "SELESAI"
        Me.logout.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label2.Location = New System.Drawing.Point(15, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 20)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Nama"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label3.Location = New System.Drawing.Point(87, 77)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(14, 20)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = ":"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label4.Location = New System.Drawing.Point(87, 54)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(14, 20)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = ":"
        '
        'tujuan
        '
        Me.tujuan.AutoSize = True
        Me.tujuan.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tujuan.ForeColor = System.Drawing.SystemColors.InfoText
        Me.tujuan.Location = New System.Drawing.Point(103, 77)
        Me.tujuan.Name = "tujuan"
        Me.tujuan.Size = New System.Drawing.Size(72, 20)
        Me.tujuan.TabIndex = 11
        Me.tujuan.Text = "TUJUAN"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label5.Location = New System.Drawing.Point(87, 33)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(14, 20)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = ":"
        '
        'lastid
        '
        Me.lastid.AutoSize = True
        Me.lastid.ForeColor = System.Drawing.SystemColors.InfoText
        Me.lastid.Location = New System.Drawing.Point(456, 162)
        Me.lastid.Name = "lastid"
        Me.lastid.Size = New System.Drawing.Size(0, 13)
        Me.lastid.TabIndex = 13
        Me.lastid.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'update_status
        '
        Me.update_status.AutoSize = True
        Me.update_status.Font = New System.Drawing.Font("Consolas", 10.0!, System.Drawing.FontStyle.Bold)
        Me.update_status.ForeColor = System.Drawing.SystemColors.InfoText
        Me.update_status.Location = New System.Drawing.Point(227, 4)
        Me.update_status.Name = "update_status"
        Me.update_status.Size = New System.Drawing.Size(72, 17)
        Me.update_status.TabIndex = 14
        Me.update_status.Text = "00:00:00"
        Me.update_status.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.Window
        Me.GroupBox1.Controls.Add(Me.komputer)
        Me.GroupBox1.Controls.Add(Me.logout)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.tujuan)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.nim)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.nama)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label_nim)
        Me.GroupBox1.Controls.Add(Me.Label_nama)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(8, 21)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(292, 166)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "                   "
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.BalloonTipTitle = "Status Log Book"
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "Status Log Book"
        Me.NotifyIcon1.Visible = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(8, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 13)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Status: "
        '
        'status_koneksistatus
        '
        Me.status_koneksistatus.AutoSize = True
        Me.status_koneksistatus.Location = New System.Drawing.Point(44, 5)
        Me.status_koneksistatus.Name = "status_koneksistatus"
        Me.status_koneksistatus.Size = New System.Drawing.Size(56, 13)
        Me.status_koneksistatus.TabIndex = 17
        Me.status_koneksistatus.Text = "Undefined"
        '
        'Status
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(309, 199)
        Me.Controls.Add(Me.status_koneksistatus)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.update_status)
        Me.Controls.Add(Me.lastid)
        Me.Controls.Add(Me.GroupBox1)
        Me.ForeColor = System.Drawing.Color.Green
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Status"
        Me.Opacity = 0.75R
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Status"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents nim As System.Windows.Forms.Label
    Friend WithEvents nama As System.Windows.Forms.Label
    Friend WithEvents komputer As System.Windows.Forms.Label
    Friend WithEvents Label_nim As System.Windows.Forms.Label
    Friend WithEvents Label_nama As System.Windows.Forms.Label
    Friend WithEvents logout As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tujuan As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lastid As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents update_status As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents status_koneksistatus As System.Windows.Forms.Label
End Class
