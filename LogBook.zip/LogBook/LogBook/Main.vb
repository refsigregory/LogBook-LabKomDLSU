﻿Imports MySql.Data.MySqlClient
Imports Microsoft.Win32
Imports System.Diagnostics
Imports System.Runtime.InteropServices
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Public Class Main
    Public tanggal As String = Format(Now, "yyyy-MM-dd")
    Dim masuk As String = Format(Now, "dd/MM/yyyy HH:mm")
    Dim tgl As String = Format(Now, "yyyy-MM-dd")
    Private Sub TimerUpdate_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerUpdate.Tick
        ' Untuk cek berkala
        DbConn()

        ' Tombol Restart jika koneksi terputus
        If statuskoneksi.Text = "Disconnected" Then
            Button2.Visible = True
            nim.ReadOnly = True
            nama.ReadOnly = True
            tujuan.ReadOnly = True
            login.Visible = False
        Else
            Button2.Visible = False
            Button2.Visible = False
            nim.ReadOnly = False
            nama.ReadOnly = False
            tujuan.ReadOnly = False
            login.Visible = True
        End If

        ' Cek Perintah
        Try
            cmd = New MySqlCommand("SELECT * FROM `perintah` WHERE komputer='" & komputer & "' and lab='" & lab & "' and `tanggal`='" + tanggal + "'", koneksi)
            rd = cmd.ExecuteReader
            rd.Read()
            If rd.HasRows Then
                If rd.Item("aksi") = "masuk" Then
                    Dim tujuan_tamu As String = rd.Item("tujuan_tamu")
                    Dim nama_tamu As String = rd.Item("nama_tamu")
                    koneksi.Close()
                    Try
                        koneksi.Open()
                        cmd = New MySqlCommand("delete from `perintah` where `komputer`='" & komputer & "' and `lab`='" & lab & "'", koneksi)
                        cmd.ExecuteNonQuery()
                        koneksi.Close()
                        MasukTamu("insert into log_list (`nim`,`nama`, `tanggal`, `lab`, `tujuan`,`komputer`,`masuk`) value('0','" & nama_tamu & "','" & tgl & "','" & lab & "','" & tujuan_tamu & "','" & komputer & "','" & masuk & "')")

                    Catch ex As Exception
                    End Try

                End If
                If rd.Item("aksi") = "bypass" Then
                    koneksi.Close()
                    koneksi.Open()
                    Try
                        cmd = New MySqlCommand("delete from `perintah` where `komputer`='" & komputer & "' and `lab`='" & lab & "'", koneksi)
                        cmd.ExecuteNonQuery()
                        koneksi.Close()
                        ByPass()
                    Catch ex As Exception
                    End Try
                End If
                If rd.Item("aksi") = "matikan" Then
                    koneksi.Close()
                    koneksi.Open()
                    Try
                        cmd = New MySqlCommand("delete from `perintah` where `komputer`='" & komputer & "' and `lab`='" & lab & "'", koneksi)
                        cmd.ExecuteNonQuery()
                        koneksi.Close()
                        Matikan()
                    Catch ex As Exception
                    End Try
                End If
                If rd.Item("aksi") = "restart" Then
                    koneksi.Close()
                    koneksi.Open()
                    Try
                        cmd = New MySqlCommand("delete from `perintah` where `komputer`='" & komputer & "' and `lab`='" & lab & "'", koneksi)
                        cmd.ExecuteNonQuery()
                        koneksi.Close()
                        Restart()
                    Catch ex As Exception
                    End Try
                End If
            End If
            koneksi.Close()
        Catch ex As Exception
        End Try
        ' End Cek Perintah

    End Sub

    Private Sub Main_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'CekUpdate()
        ' Wallpaper Desktop
        Dim RKey = Registry.CurrentUser.OpenSubKey("Control Panel\Desktop", False)
        Me.BackgroundImage = Image.FromFile(RKey.GetValue("Wallpaper"))

        ' Background Transparan
        Panel1.BackColor = Color.FromArgb(50, 50, 50, 50)
        Label1.BackColor = Color.FromArgb(0, 50, 50, 50)
        Label6.BackColor = Color.FromArgb(0, 50, 50, 50)
        Label5.BackColor = Color.FromArgb(0, 200, 200, 200)
        namalab.BackColor = Color.FromArgb(0, 50, 50, 50)
        statuskoneksi.BackColor = Color.FromArgb(0, 59, 50, 50)
        statuskoneksi.ForeColor = Color.Green
        nokomputer.BackColor = Color.FromArgb(0, 200, 200, 200)
        logo_main.BackColor = Color.FromArgb(0, 200, 200, 200)
        'Credit.BackColor = Color.FromArgb(0, 200, 200, 200)

        'nim.BackColor = Color.FromArgb(100, 200, 200, 200)
        'nama.BackColor = Color.FromArgb(100, 200, 200, 200)
        'tujuan.BackColor = Color.FromArgb(100, 200, 200, 200)

        Timer1.Start()
        TimerUpdate.Start()
        HookKeyboard()
        UpgradeMySetings()
        cek()
        nokomputer.Visible = True
        namalab.Text = "Laboratorium " & lab
        Dim labs As String = Replace(lab, " ", "")
        nokomputer.Text = labs + "-" + komputer
        Dim a As String = My.Settings.peraturan_text

        'Caption di TexBox
        nim.Text = "NIM Mahasiswa"
        nama.Text = "Nama Mahasiswa"
        tujuan.Text = "Tujuan Penggunaan"

    End Sub

    Dim tulisan(5) As String
    Dim i, j As Integer
    Public Action As String

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ' Kill Proses Explorer dan TaskManager
        Try
            For Each selProcess As Process In Process.GetProcesses
                If selProcess.ProcessName = "explorer" Then
                    selProcess.Kill()
                    Exit For
                End If
            Next
            For Each selProcess As Process In Process.GetProcesses
                If selProcess.ProcessName = "taskmgr" Then
                    ' selProcess.Kill()
                    Exit For
                End If
            Next
        Catch ex As Exception
        End Try
        ' End Kill
    End Sub

    ' Koneksi
    Dim koneksi As New MySqlConnection
    Public da As MySqlDataAdapter
    Public dt As DataTable
    Public ds As DataSet
    Public cd As MySqlCommand
    Public cmd As MySqlCommand
    Public rd As MySqlDataReader
    Dim stringkoneksi As String = "Server=" + conf_server + ";User Id=" + conf_userdb + ";Password=" + conf_passdb + ";Database=" + conf_dbname + ""
    Dim perintahmysql As New MySqlCommand
    Dim perintahsql As New SqlCommand
    Public time As String = Format(Now, "dd/MM/yyyy HH:mm:ss")
    Public Sub cek()
        'Cek Jika sudah dikofigurasi
        judul_peraturan_box.Text = "Peraturan Lab " & lab
        peraturan_text.Text = My.Settings.peraturan_text
        Credit.Text = "© 2016 Laboratorium " + lab + ". Created by " + credits + "."
        'Dim strINIFile As String = Application.StartupPath + "\Config.ini"
        'If GetIniSetting(strINIFile, "Setting", "NoKomputer") = "NOT_FOUND" Then
        If komputer = 0 Then
            Config.Show()
            Me.Hide()
        Else
            Dim wizard As String
            wizard = MsgBox("Selamat Datang di Log Book Laboratorium " + lab + "! Sebelum menggunakan komputer jangan lupa untuk terlebih dahulu mengisi NIM, Nama dan Tujuan Penggunaan (Seperti halnya di Log Book Biasanya). Jika ada pertanyaan hubungi Aslab.", vbApplicationModal + vbInformation, "Selamat Datang!")
        End If
    End Sub
    Public komputer As String = conf_no
    Public server As String = conf_server
    Public ip As String = conf_ip
    Public lab As String = conf_lab
    Sub DbConn()
        Try
            If koneksi Is Nothing Or Not koneksi.State = ConnectionState.Open Then 'jika tidak ada koneksi atau koneksi mysql tidak dibuka
                koneksi = New MySqlConnection(stringkoneksi)
                'membuka koneksi mysql
                koneksi.Open()
                statuskoneksi.Text = "Connected"
                statuskoneksi.ForeColor = Color.Green
            Else
                koneksi.Close()
                koneksi = New MySqlConnection(stringkoneksi)
                'membuka koneksi mysql
                koneksi.Open()
                statuskoneksi.Text = "Connected"
                statuskoneksi.ForeColor = Color.Green
            End If
        Catch ex As Exception
            If statuskoneksi.Text <> "Disconnected" Then
                statuskoneksi.Text = "Disconnected"
                statuskoneksi.ForeColor = Color.Red
            End If
        End Try
    End Sub
    Sub koneksilama()
        koneksi.ConnectionString = stringkoneksi

        Try
            If koneksi.State = ConnectionState.Closed Then
                koneksi.Open()
                statuskoneksi.Text = "Connected"
            Else
                koneksi.Close()
            End If
        Catch ex As Exception
            Dim pilihankoneksi As String = MsgBox("Koneksi Gagal, Hubungi Aslab!", vbCritical + vbRetryCancel, "Koneksi Gagal")
            If pilihankoneksi = vbRetry Then
                Application.Restart()
            Else
                Action = "exit"
                InputPassword.Show()
                Dim ExProcess = New Process()
                ExProcess.StartInfo.UseShellExecute = True
                ExProcess.StartInfo.CreateNoWindow = True
                ExProcess.StartInfo.FileName = "c:\windows\explorer.exe"
                ExProcess.StartInfo.WorkingDirectory = Application.StartupPath
                ExProcess.Start()
            End If
        End Try

    End Sub
    ' End Koneksi
    Sub MasukMahasiswa()
        DbConn()
        Dim kalimatmysql As String = "insert into log_list (`nim`,`nama`, `tanggal`, `lab`, `tujuan`,`komputer`,`masuk`) value('" & nim.Text & "','" & nama.Text & "','" & tgl & "','" & lab & "','" & tujuan.Text & "','" & komputer & "','" & masuk & "')"
        Dim sqlquery = "Select max(id) from log_list limit 1"
        Dim cmd As New MySqlCommand(sqlquery, koneksi)
        Status.lastid.Text = cmd.ExecuteScalar() + 1
        'regex
        'Dim filter As New Regex("[^main^|^browsing^|^facebook^]")
        'If (rx.IsMatch()) Then
        'End If

        ' menghitung jumlah kata
        Dim jumlah_nama As String = UBound(Split(nama.Text, " ")) 'InStr(nama.Text, " ")
        Dim jumlah_tujuan As String = UBound(Split(tujuan.Text, " "))

        If nim.Text <> "" And nama.Text <> "" And nama.Text <> "Nama Mahasiswa" And IsNumeric(nim.Text) And tujuan.Text <> "" And tujuan.Text <> "Tujuan Penggunaan" And jumlah_nama >= 1 And jumlah_tujuan >= 1 Then

            If Len(nim.Text) = 8 Then
                With perintahmysql
                    .CommandText = kalimatmysql
                    .CommandType = CommandType.Text
                    .Connection = koneksi
                    .ExecuteNonQuery()
                End With
                statuskoneksi.Show()
                UnhookKeyboard()
                Status.Show()
                Me.Hide()
            Else
                MsgBox("NIM Anda Salah! Pastikan NIM anda sesuai Format.", MsgBoxStyle.Exclamation)
            End If

        Else
            MsgBox("Harap Mengisi NIM, Nama dan Tujuan Penggunaan Komputer! Pastikan sudah mengisi dengan benar dan sesuai format (NIM ASLI, NAMA LENGKAP dan TUJUAN YANG JELAS).", MsgBoxStyle.Exclamation)
        End If
        koneksi.Close()
    End Sub

    Sub MasukTamu(ByVal kirim As String)
        koneksi.Open()
        Dim masuk As String = Format(Now, "dd/MM/yyyy HH:mm")
        Dim tgl As String = Format(Now, "yyyy-MM-dd")
        Dim kalimatmysql As String = kirim
        Dim sqlquery = "Select max(id) from log_list limit 1"
        Dim cmd As New MySqlCommand(sqlquery, koneksi)
        Status.lastid.Text = cmd.ExecuteScalar() + 1

        With perintahmysql
            .CommandText = kalimatmysql
            .CommandType = CommandType.Text
            .Connection = koneksi
            .ExecuteNonQuery()
        End With
        UnhookKeyboard()
        Status.Show()
        Me.Hide()
        koneksi.Close()
    End Sub


    ' Error Validasi

    Sub ByPass()
        Application.Exit()
    End Sub

    Sub Matikan()
        Shell("shutdown -s -f -t 0")
    End Sub

    Sub Restart()
        Shell("shutdown -r -f -t 0")
    End Sub

    Private Sub nim_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles nim.Validated
        If nim.Text = "" Or nim.Text = "NIM Mahasiswa" Then
            ErrorProvider1.SetError(nim, "NIM tidak boleh kosong")
        Else
            ErrorProvider1.SetError(nim, "")
            If Len(nim.Text) = 8 Then
                ' sesuai format
                ErrorProvider1.SetError(nim, "")
            Else
                ErrorProvider1.SetError(nim, "Format Nim Anda Salah, Jika NIM Anda kurang dari 8 Digit tambahkan angka 0 di depan. Misal: 09013001")
            End If
        End If
    End Sub

    Private Sub nama_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles nama.Validated
        If nama.Text = "" Or nama.Text = "Nama Mahasiswa" Then
            ErrorProvider1.SetError(nama, "Nama tidak boleh kosong")
        Else
            ErrorProvider1.SetError(nama, "")

            ' menghitung jumlah kata
            Dim jumlah_nama As String = UBound(Split(nama.Text, " "))

            If jumlah_nama >= 1 Then
                ' sesuai format
                ErrorProvider1.SetError(nama, "")

                nama.Text = StrConv(nama.Text, VbStrConv.ProperCase)
            Else
                ErrorProvider1.SetError(nama, "Harap memasukan NAMA LENGKAP Anda")
            End If
        End If
    End Sub

    Private Sub Tujuan_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles tujuan.Validated
        If tujuan.Text = "" Or tujuan.Text = "Tujuan Penggunaan" Then
            ErrorProvider1.SetError(tujuan, "Tujuan Penggunaan tidak boleh kosong")
        Else
            ErrorProvider1.SetError(tujuan, "")

            ' menghitung jumlah kata
            Dim jumlah_tujuan As String = UBound(Split(tujuan.Text, " "))

            If jumlah_tujuan >= 1 Then
                ' sesuai format
                ErrorProvider1.SetError(tujuan, "")

                tujuan.Text = StrConv(tujuan.Text, VbStrConv.ProperCase)
            Else
                ErrorProvider1.SetError(tujuan, "Harap memasukan TUJUAN PENGGUNAAN YANG JELAS")
            End If
        End If
    End Sub

    ' End Validasi

    Public Sub login_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles login.Click
        If statuskoneksi.Text = "Connected" Then
            MasukMahasiswa()
        Else
            MsgBox("Koneksi dengan Server Gagal! Restart Aplikasi untuk mencoba menghubungkan dengan Server lagi atau hubungi Aslab.", MsgBoxStyle.Exclamation)
        End If

    End Sub

    Public Sub UpgradeMySetings()
        If My.Settings.MustUpgrade Then
            My.Settings.Upgrade()
            My.Settings.MustUpgrade = False
            My.Settings.Save()
        End If
    End Sub

    Private Sub nim_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nim.Click
        nim.Text = ""
    End Sub

    Private Sub nama_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nama.Click
        nama.Text = ""
    End Sub

    Private Sub tujuan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tujuan.Click
        tujuan.Text = ""
    End Sub
    Private Sub statuskoneksi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles statuskoneksi.Click
        Application.Restart()
    End Sub

    Private Sub Credit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Credit.Click
        About.Show()
    End Sub

    Private Sub KofigurasiToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KofigurasiToolStripMenuItem.Click
        Action = "config"
        InputPassword.Show()
    End Sub

    Private Sub TutupToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TutupToolStripMenuItem.Click
        Action = "exit"
        InputPassword.Show()
        Dim ExProcess = New Process()
        ExProcess.StartInfo.UseShellExecute = True
        ExProcess.StartInfo.CreateNoWindow = True
        ExProcess.StartInfo.FileName = "c:\windows\explorer.exe"
        ExProcess.StartInfo.WorkingDirectory = Application.StartupPath
        ExProcess.Start()
    End Sub
    Private Sub shutdown_button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles shutdown_button.Click
        Shell("shutdown -s -f -t 0")
    End Sub

    Private Sub restart_button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles restart_button.Click
        Shell("shutdown -r -f -t 0")
    End Sub

    Private Sub nim_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nim.LostFocus
        If nim.Text = "" Then
            nim.Text = "NIM Mahasiswa"

        End If
    End Sub
    Private Sub nama_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nama.LostFocus
        If nama.Text = "" Then
            nama.Text = "Nama Mahasiswa"
        End If
    End Sub
    Private Sub tujuan_LostFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tujuan.LostFocus
        If tujuan.Text = "" Then
            tujuan.Text = "Tujuan Penggunaan"
        End If
    End Sub

    Private Sub Timer_text_berjalan_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer_text_berjalan.Tick
        If i.Equals(tulisan(j).Length) Then
            Me.text_berjalan.Text = ""
            If j < tulisan.Length - 1 Then
                j = j + 1
            Else
                j = 0
            End If
            i = 0
        End If
        text_berjalan.Text = tulisan(j).Substring(0, i)
        i = i + 1
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Button1.Enabled = False
        Button1.Text = "Checking for updates..."
        Timer1.Start()
        Label1.Text = ProgressBar1.Value
        CekUpdate()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Application.Restart()
    End Sub
    Protected Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            Const CS_NOCLOSE As Integer = &H200
            cp.ClassStyle = cp.ClassStyle Or CS_NOCLOSE
            Return cp
        End Get
    End Property

    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, ByVal keyData As Keys) As Boolean
        If keyData = (Keys.Control Or Keys.F4) Then Return True
        Return MyBase.ProcessCmdKey(msg, keyData)
    End Function

    Public Sub CekUpdate()
        'If ProgressBar1.Value = 100 Then
        'Dim request As System.Net.HttpWebRequest = System.Net.HttpWebRequest.Create("http://192.168.5.164/LogBook/latestVersion.txt")
        'Dim response As System.Net.HttpWebResponse = request.GetResponse()

        'Dim sr As System.IO.StreamReader = New System.IO.StreamReader(response.GetResponseStream())

        'Dim newestversion As String = sr.ReadToEnd()
        'Dim currentversion As String = Application.ProductVersion
        'If newestversion.Contains(currentversion) Then
        'Button1.Text = ("You are up todate!")
        'Label2.Text = ("You may now close this dialog")
        'Else
        'Button1.Text = ("Downloading update!")
        'WebBrowser1.Navigate("http://192.168.5.164/LogBook/Installer/LogBook_" + newestversion + ".msi")
        'Label2.Text = ("You may now close this dialog")
        'End If
        'End If
    End Sub


    'Event types
    Private Const WM_KEYUP As Integer = &H101
    Private Const WM_KEYDOWN As Short = &H100S
    Private Const WM_SYSKEYDOWN As Integer = &H104
    Private Const WM_SYSKEYUP As Integer = &H105
    'Event Info structure
    Public Structure KBDLLHOOKSTRUCT
        Public vkCode As Integer
        Public scanCode As Integer
        Public flags As Integer
        Public time As Integer
        Public dwExtraInfo As Integer
    End Structure
    'Keyboard hook related functions
    Private Declare Function UnhookWindowsHookEx Lib "user32" (ByVal hHook As Integer) As Integer
    Private Declare Function SetWindowsHookEx Lib "user32" Alias "SetWindowsHookExA" (ByVal idHook As Integer, ByVal lpfn As KeyboardHookDelegate, ByVal hmod As Integer, ByVal dwThreadId As Integer) As Integer
    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Integer) As Integer
    Private Declare Function CallNextHookEx Lib "user32" (ByVal hHook As Integer, ByVal nCode As Integer, ByVal wParam As Integer, ByVal lParam As KBDLLHOOKSTRUCT) As Integer
    Private Delegate Function KeyboardHookDelegate(ByVal Code As Integer, ByVal wParam As Integer, ByRef lParam As KBDLLHOOKSTRUCT) As Integer
    Private KeyboardHandle As IntPtr = 0 'Handle of the hook
    Private callback As KeyboardHookDelegate = Nothing 'Delegate for the hook
    Private Function Hooked()
        Return KeyboardHandle <> 0 'If KeyboardHandle = 0 it means that it isn't hooked so return false, otherwise return true
    End Function
    Public Sub HookKeyboard()
        callback = New KeyboardHookDelegate(AddressOf KeyboardCallback)
        KeyboardHandle = SetWindowsHookEx(13, callback, Process.GetCurrentProcess.MainModule.BaseAddress, 0)
        If KeyboardHandle <> 0 Then
            Debug.Write(vbCrLf & "[Keyboard Hooked]" & vbCrLf)
        End If
    End Sub
    Public Sub UnhookKeyboard()
        If (Hooked()) Then
            If UnhookWindowsHookEx(KeyboardHandle) <> 0 Then
                Debug.Write(vbCrLf & "[Keyboard Unhooked]")
                KeyboardHandle = 0 'We have unhooked successfully
            End If
        End If
    End Sub
    Public Function KeyboardCallback(ByVal Code As Integer, ByVal wParam As Integer, ByRef lParam As KBDLLHOOKSTRUCT) As Integer
        'Variable to hold the text describing the key pressed
        Dim Key = lParam.vkCode
        'If event is KEYDOWN
        If wParam = WM_KEYDOWN Or wParam = WM_SYSKEYDOWN Then
            'If we can block events
            If Code >= 0 Then
                If Key = 91 Or Key = 92 Then
                    Return 1 'Block event
                End If
            End If
        End If
        Debug.Write(Key)
        'Return CallNextHookEx(KeyboardHandle, Code, wParam, lParam) 'Let event go to the other applications
        Return ""
    End Function

    'Dim strINIFile As String = Application.StartupPath + "\Config.ini"
    'Public komputer As String = GetIniSetting(strINIFile, "Setting", "NoKomputer")
    'Public server As String = GetIniSetting(strINIFile, "Setting", "Server")
    'Public ip As String = GetIniSetting(strINIFile, "Setting", "NoIP")
    'Public lab As String = GetIniSetting(strINIFile, "Setting", "Lab")
End Class

