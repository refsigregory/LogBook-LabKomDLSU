﻿Imports System.Windows.Forms
Imports Microsoft.Win32

Public Class Config

    Private Sub Config_Load(ByVal sender As System.Object, _
                ByVal e As System.EventArgs) Handles MyBase.Load
        text_server.Text = conf_server
        text_ip.Text = conf_ip
        lab_server.Text = conf_labserver
        text_lab.Text = conf_lab
        text_no.Text = conf_no
        text_userdb.Text = conf_userdb
        text_passdb.Text = conf_passdb
        text_dbname.Text = conf_dbname
        password_text.Text = My.Settings.password
        peraturan_text.Text = My.Settings.peraturan_text

        CheckBox1.Checked = True
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, _
                ByVal e As System.EventArgs) Handles OK_Button.Click
        With My.Settings
            .conf_server = text_server.Text
            .conf_ip = text_ip.Text
            .conf_labserver = lab_server.Text
            .conf_lab = text_lab.Text
            .conf_no = text_no.Text
            .conf_userdb = text_userdb.Text
            .conf_passdb = text_passdb.Text
            .conf_dbname = text_dbname.Text
            .peraturan_text = peraturan_text.Text
            .password = password_text.Text
            .Save()
        End With

        'Membuat StartUp Program
        Dim AppName, AppPath As String
        AppName = Application.ProductName 'Nama aplikasi
        AppPath = Application.StartupPath 'Alamat (Path) aplikasi

        Dim applicationName As String = Application.ProductName
        Dim applicationPath As String = Application.ExecutablePath

        If CheckBox1.Checked Then
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True)
            regKey.SetValue(applicationName, """" & applicationPath & """")
            regKey.Close()
        Else
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True)
            regKey.DeleteValue(applicationName, False)
            regKey.Close()
        End If


        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Application.Restart()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, _
                ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub
End Class
