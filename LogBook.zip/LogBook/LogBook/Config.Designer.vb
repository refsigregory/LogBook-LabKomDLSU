﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Config
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.text_server = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.text_no = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.text_ip = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.text_dbname = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.text_passdb = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.text_userdb = New System.Windows.Forms.TextBox()
        Me.text_lab = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.peraturan_text = New System.Windows.Forms.TextBox()
        Me.Labelpassword = New System.Windows.Forms.Label()
        Me.password_text = New System.Windows.Forms.TextBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lab_server = New System.Windows.Forms.TextBox()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(277, 467)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'text_server
        '
        Me.text_server.Location = New System.Drawing.Point(140, 89)
        Me.text_server.Name = "text_server"
        Me.text_server.Size = New System.Drawing.Size(263, 20)
        Me.text_server.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 92)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "IP Server LogBook"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(32, 163)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Nomor Komputer"
        '
        'text_no
        '
        Me.text_no.Location = New System.Drawing.Point(140, 165)
        Me.text_no.Name = "text_no"
        Me.text_no.Size = New System.Drawing.Size(263, 20)
        Me.text_no.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(32, 137)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "IP Komputer"
        '
        'text_ip
        '
        Me.text_ip.Location = New System.Drawing.Point(140, 139)
        Me.text_ip.Name = "text_ip"
        Me.text_ip.Size = New System.Drawing.Size(263, 20)
        Me.text_ip.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(32, 188)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Nama Database"
        '
        'text_dbname
        '
        Me.text_dbname.Location = New System.Drawing.Point(140, 190)
        Me.text_dbname.Name = "text_dbname"
        Me.text_dbname.Size = New System.Drawing.Size(263, 20)
        Me.text_dbname.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(32, 240)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Password Database"
        '
        'text_passdb
        '
        Me.text_passdb.Location = New System.Drawing.Point(140, 242)
        Me.text_passdb.Name = "text_passdb"
        Me.text_passdb.Size = New System.Drawing.Size(263, 20)
        Me.text_passdb.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(32, 214)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "User Database"
        '
        'text_userdb
        '
        Me.text_userdb.Location = New System.Drawing.Point(140, 216)
        Me.text_userdb.Name = "text_userdb"
        Me.text_userdb.Size = New System.Drawing.Size(263, 20)
        Me.text_userdb.TabIndex = 11
        '
        'text_lab
        '
        Me.text_lab.FormattingEnabled = True
        Me.text_lab.Items.AddRange(New Object() {"Multimedia", "Pemrograman", "Basis Data"})
        Me.text_lab.Location = New System.Drawing.Point(140, 62)
        Me.text_lab.Name = "text_lab"
        Me.text_lab.Size = New System.Drawing.Size(263, 21)
        Me.text_lab.TabIndex = 13
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(32, 65)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Laboratorium"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(109, 21)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(224, 25)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Kofigurasi Log Book"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(32, 297)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 13)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Peraturan Lab"
        '
        'peraturan_text
        '
        Me.peraturan_text.Location = New System.Drawing.Point(140, 302)
        Me.peraturan_text.Multiline = True
        Me.peraturan_text.Name = "peraturan_text"
        Me.peraturan_text.Size = New System.Drawing.Size(263, 110)
        Me.peraturan_text.TabIndex = 17
        '
        'Labelpassword
        '
        Me.Labelpassword.AutoSize = True
        Me.Labelpassword.Location = New System.Drawing.Point(32, 266)
        Me.Labelpassword.Name = "Labelpassword"
        Me.Labelpassword.Size = New System.Drawing.Size(53, 13)
        Me.Labelpassword.TabIndex = 19
        Me.Labelpassword.Text = "Password"
        '
        'password_text
        '
        Me.password_text.Location = New System.Drawing.Point(140, 271)
        Me.password_text.Name = "password_text"
        Me.password_text.Size = New System.Drawing.Size(263, 20)
        Me.password_text.TabIndex = 18
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(140, 428)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(102, 17)
        Me.CheckBox1.TabIndex = 20
        Me.CheckBox1.Text = "Startup Program"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(32, 117)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(72, 13)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "IP Server Lab"
        '
        'lab_server
        '
        Me.lab_server.Location = New System.Drawing.Point(140, 114)
        Me.lab_server.Name = "lab_server"
        Me.lab_server.Size = New System.Drawing.Size(263, 20)
        Me.lab_server.TabIndex = 21
        '
        'Config
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(435, 508)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.lab_server)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.Labelpassword)
        Me.Controls.Add(Me.password_text)
        Me.Controls.Add(Me.peraturan_text)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.text_lab)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.text_userdb)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.text_passdb)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.text_dbname)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.text_ip)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.text_no)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.text_server)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Config"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Kofigurasi Log Book"
        Me.TopMost = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents text_server As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents text_no As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents text_ip As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents text_dbname As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents text_passdb As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents text_userdb As System.Windows.Forms.TextBox
    Friend WithEvents text_lab As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents peraturan_text As System.Windows.Forms.TextBox
    Friend WithEvents Labelpassword As System.Windows.Forms.Label
    Friend WithEvents password_text As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lab_server As System.Windows.Forms.TextBox

End Class
